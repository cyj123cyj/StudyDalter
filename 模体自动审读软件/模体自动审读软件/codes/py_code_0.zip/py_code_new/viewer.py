# -*- coding: utf-8 -*-
#导入需要的模块
from __future__ import division
import os, scipy
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import sys, pylab;
#from SprialBeadsLauncher import *
import linear
#import sys
import xlwt
import xlrd
from xlutils.copy import copy;
from qtpy import QtWidgets, QtCore
from languagecheck import languageok
import dicom
import numpy as np
import os.path


from util import *
from dicom_widget_data import DicomData,DicomWidget
#from util import dicom_files_in_dir
from resolution import *
from thickness import SpiralBeads, CT_phantom
from scipy import stats

import matplotlib
matplotlib.use('Qt4Agg', warn=False)

from PyQt4 import QtCore, QtGui
from math import sqrt
from PyQt4.QtCore import SIGNAL
from PyQt4.QtGui import QFileDialog, QDialog, QApplication, QWidget, \
    QPushButton, QLabel, QLineEdit, QHBoxLayout, QFormLayout,QStringListModel,QMessageBox
#    from PyQt4.QtGui import *
from PyQt4.QtCore import QDir,QTranslator

from water import Water_Phantom,DICOM,InvalidDicomError
from linear import*
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

'''class TrackingLabel(QtWidgets.QLabel):
    def __init__(self, parent):
        super(TrackingLabel, self).__init__(parent)
        self.setMouseTracking(True)
        self.last_move_x = None
        self.last_move_y = None
        self.window = parent

    def mouseLeaveEvent(self, event):
        self.parent().mouse_x = -1
        self.parent().mouse_y = -1
       # self.parent().update_coordinates()

    def mouseMoveEvent(self, event):
        self.window.mouse_x = event.x()
        self.window.mouse_y = event.y()
       # self.window.update_coordinates()

        if event.buttons() == QtCore.Qt.LeftButton:
            self.window.window_width += event.y() - self.last_move_y
            self.window.window_center += event.x() - self.last_move_x

            self.last_move_x = event.x()
            self.last_move_y = event.y()

    def mousePressEvent(self, event):
        self.last_move_x = event.x()
        self.last_move_y = event.y()
        print(self.last_move_x,self.last_move_y)
    def mouseReleaseEvent(self, event):
        self.last_move_x = None
        self.last_move_y = None

    def wheelEvent(self, event):
        file_list = self.window.file_list
        if len(file_list.selectedItems()):
            index = file_list.row(file_list.selectedItems()[0])
        else:
            index = -1
        if event.delta() > 0:
            index -= 1
        else:
            index += 1

        if index >= file_list.count() or index == -2:
            index = file_list.count() - 1
        elif index < 0:
            index = 0

        file_list.setCurrentItem(file_list.item(index))'''

class Viewer(QtWidgets.QMainWindow):
    def __init__(self, path = None,min1 = 0,max1 = 0,resolution = 0,av = 0,lcd = 0,noise = 0,homogeneity = 0,mean1 = 0):
        super(Viewer, self).__init__()
        #初始化一些初值
        self.mgy = 0
        self.mgy1 = 0
        self.setMinimumSize(1366,768)
        self.slice8_biaocheng = 0
        self.slice8_shice = 0
        self.slice8_err = 0
        self.slice28_biaocheng = 0
        self.slice28_shice = 0
        self.slice28_err = 0
        self.slice2_biaocheng = 0
        self.slice2_shice = 0
        self.slice2_err = 0
        self.place=0
        self.setWindowTitle(_translate("","CT设备成像质量检测系统",None))
        self.file = None
        self.array3 = [0,0,0,0,0,0,0,0]
        self.high_hu = 2000
        self.low_hu = -1024
        self.noise = noise
        self.min1 = min1
        self.max1 = max1
        self.mean1 = mean1
        self.lcd = lcd
        self.resolution = resolution
        self.homogeneity = homogeneity
        self.av = av
        self.av2 = 0
        self.av3 = 0
        self.av5 = 0
        self.av7 = 0
        self.a0 = 0
        self.a1 = 0
        self.a2 = 0
        self.a3 = 0
        self.a4 = 0
        self.a5 = 0
        self.a6 = 0
        self.a7 = 0
        self.a8 = 0
        self.a9 = 0
        self.array1 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ,0.0]
        self.dcmKVP = 0
        self.dcmXRayTubeCurrent = 0
        self.dcmExposureTime = 0

        self.ctLilunDef = [-1000.0, -630.0, -100.0, 120.0, 365.0, 550.0, 1000.0, 1280.0] # 默认八种材料的CT理论值

        #self.pix_label1 = TrackingLabel(self)
        self.pix_label = DicomWidget(parent = self, kwargs = None)
        #self.pix_label.setCursor(QtCore.Qt.CrossCursor)
        self.resolution10 = 0
        self.resolution50 = 0
        self.resolution10x = 0
        self.resolution50x = 0
        self.mid = 0
        self.length = 255
        scroll_area = QtWidgets.QScrollArea()
        scroll_area.setWidget(self.pix_label)

        #对比度调节滑块的设定
        self.horizontalSlider = QtGui.QSlider(scroll_area)
        self.horizontalSlider.setGeometry(QtCore.QRect(0, 514, 512, 19))
        self.horizontalSlider.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider1 = QtGui.QSlider(scroll_area)
        self.horizontalSlider1.setGeometry(QtCore.QRect(0, 542, 512, 19))
        self.horizontalSlider1.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider1.setObjectName(_fromUtf8("horizontalSlider1"))
        self.label_duibidu = QtGui.QLabel(scroll_area)
        self.label_duibidu.setGeometry(QtCore.QRect(245,563,120,30))
        self.label_duibidu.setText(_translate("", "对比度调节", None))
        self.horizontalSlider.setMinimum(0)
        self.horizontalSlider.setMaximum(255)
        self.horizontalSlider1.setMinimum(0)
        self.horizontalSlider1.setMaximum(255)
        self.horizontalSlider1.setSliderPosition(self.horizontalSlider1.maximum())
        #机架倾角的标签位置和编辑框的设定
        self.label_angle = QtGui.QLabel(scroll_area)
        self.label_angle.setGeometry(QtCore.QRect(10, 593, 60, 30))
        self.label_angle.setText(_translate("", "机架倾角", None))
        self.lineEdit_angle = QtGui.QLineEdit(scroll_area)
        self.lineEdit_angle.setGeometry(QtCore.QRect(71,593,100,19))
        self.lineEdit_angle.setEnabled(0)
        #机架倾角选择计算按钮的设定
        self.pushButton_angle = QtGui.QPushButton(scroll_area)
        self.pushButton_angle.setGeometry(QtCore.QRect(182, 590, 80, 25))

        self.pushButton_angle.setText(_translate("", "计算", None))

        #生成报告按钮的设定
        self.pushButton_report = QtGui.QPushButton(scroll_area)
        self.pushButton_report.setGeometry(QtCore.QRect(320, 590, 201, 30))
        self.pushButton_report.setObjectName(_fromUtf8("pushButton_report"))
        self.widget = QtGui.QWidget(scroll_area)
        self.widget.setGeometry(QtCore.QRect(520, 0, 574, 631))#窗口部件
        self.widget.setObjectName(_fromUtf8("widget"))
        self.gridLayout_all = QtGui.QGridLayout(self.widget)#布局
        self.gridLayout_all.setObjectName(_fromUtf8("gridLayout_all"))
        self.gridLayout_all.setColumnStretch(0, 1)
        self.gridLayout_all.setColumnStretch(1, 5)
        self.resolution50 = 0
        self.resolution10 = 0
        self.CT_err = 0
        
        self.label_diam = QtGui.QLabel(scroll_area)
        self.lineEdit_diam = QtGui.QLineEdit(scroll_area)
        self.label_diammm = QtGui.QLabel(scroll_area)
        self.label_pitch = QtGui.QLabel(scroll_area)
        self.lineEdit_pitch = QtGui.QLineEdit(scroll_area)
        self.label_pitchmm = QtGui.QLabel(scroll_area)
        self.label_diam.setObjectName(_fromUtf8("label_diam"))
        self.lineEdit_diam.setObjectName(_fromUtf8("lineEdit_diam"))
        self.label_diammm.setObjectName(_fromUtf8("label_diammm"))
        self.label_pitch.setObjectName(_fromUtf8("label_pitch"))
        self.lineEdit_pitch.setObjectName(_fromUtf8("lineEdit_pitch"))
        self.label_pitchmm.setObjectName(_fromUtf8("label_pitchmm"))
        self.label_diam.setGeometry(QtCore.QRect(10, 630, 60, 30))
        self.lineEdit_diam.setGeometry(QtCore.QRect(80, 633, 100, 19))
        self.label_diammm.setGeometry(QtCore.QRect(181, 630, 20, 30))
        self.label_pitch.setGeometry(QtCore.QRect(370, 630, 60, 30))
        self.lineEdit_pitch.setGeometry(QtCore.QRect(400, 633, 100, 19))
        self.label_pitchmm.setGeometry(QtCore.QRect(501, 630, 20, 30))
        self.label_num = QtGui.QLabel(scroll_area)
        self.lineEdit_num = QtGui.QLineEdit(scroll_area)
        self.label_num.setObjectName(_fromUtf8("label_diam"))
        self.lineEdit_num.setObjectName(_fromUtf8("lineEdit_diam"))
        self.label_num.setGeometry(QtCore.QRect(10, 660, 60, 30))
        self.lineEdit_num.setGeometry(QtCore.QRect(80, 663, 100, 19))
        self.lineEdit_diam.setText("162.4")
        self.lineEdit_pitch.setText("90")
        self.lineEdit_num.setText("180")
        self.diam = 162.4
        self.pitch = 90
        self.beadsnum = 180


        # 水模体指标
        self.groupBox_water = QtGui.QGroupBox(self.widget)#水模体框
        self.gridLayout_water = QtGui.QGridLayout(self.groupBox_water)
        self.water_pushButton = QtGui.QPushButton(self.groupBox_water)#水模体部分计算按钮
        self.water_label_CT = QtGui.QLabel(self.groupBox_water)#水模体部分CT值标签
        self.water_lineEdit_CT = QtGui.QLineEdit(self.groupBox_water)#水模体部分CT值编辑框
        self.water_lineEdit_CT.setReadOnly(True)
        self.water_label_noise = QtGui.QLabel(self.groupBox_water)#水模体部分噪声标签
        self.water_lineEdit_noise = QtGui.QLineEdit(self.groupBox_water)#水模体部分噪声编辑框
        self.water_label_junyun = QtGui.QLabel(self.groupBox_water)#水模体部分均匀性标签
        self.water_lineEdit_junyun = QtGui.QLineEdit(self.groupBox_water)#水模体部分均匀性编辑框
        self.water_label_lcd = QtGui.QLabel(self.groupBox_water)#水模体部分低对比可探测能力标签
        self.water_label_lcd_2 = QtGui.QLabel(self.groupBox_water)#水模体部分低对比可探测能力2标签
        self.water_label_lcd_3 = QtGui.QLabel(self.groupBox_water)#水模体部分低对比可探测能力3标签
        self.water_label_lcd_5 = QtGui.QLabel(self.groupBox_water)#水模体部分低对比可探测能力5标签
        self.water_label_lcd_7 = QtGui.QLabel(self.groupBox_water)#水模体部分低对比可探测能力7标签
        self.water_lineEdit_lcd_2 = QtGui.QLineEdit(self.groupBox_water)#水模体部分低对比可探测能力2编辑框
        self.water_lineEdit_lcd_3 = QtGui.QLineEdit(self.groupBox_water)#水模体部分低对比可探测能力3编辑框
        self.water_lineEdit_lcd_5= QtGui.QLineEdit(self.groupBox_water)#水模体部分低对比可探测能力5编辑框
        self.water_lineEdit_lcd_7 = QtGui.QLineEdit(self.groupBox_water)#水模体部分低对比可探测能力7编辑框
        
        
        #水模体部分设置目标名称
        self.groupBox_water.setObjectName(_fromUtf8("groupBox_water"))
        self.gridLayout_water.setObjectName(_fromUtf8("gridLayout_water"))
        self.water_pushButton.setObjectName(_fromUtf8("water_pushButton"))
        self.water_label_CT.setObjectName(_fromUtf8("water_label_CT"))
        self.water_lineEdit_CT.setObjectName(_fromUtf8("water_lineEdit_CT"))
        self.water_label_noise.setObjectName(_fromUtf8("water_label_noise"))
        self.water_lineEdit_noise.setObjectName(_fromUtf8("water_lineEdit_noise"))
        self.water_label_junyun.setObjectName(_fromUtf8("water_label_junyun"))
        self.water_lineEdit_junyun.setObjectName(_fromUtf8("water_lineEdit_junyun"))
        self.water_label_lcd.setObjectName(_fromUtf8("water_label_lcd"))
        self.water_label_lcd_2.setObjectName(_fromUtf8("2"))
        self.water_label_lcd_3.setObjectName(_fromUtf8("3"))
        self.water_label_lcd_5.setObjectName(_fromUtf8("5"))
        self.water_label_lcd_7.setObjectName(_fromUtf8("7"))
        self.water_lineEdit_lcd_2.setObjectName(_fromUtf8("water_lineEdit_lcd_2"))
        self.water_lineEdit_lcd_3.setObjectName(_fromUtf8("water_lineEdit_lcd_3"))
        self.water_lineEdit_lcd_5.setObjectName(_fromUtf8("water_lineEdit_lcd_5"))
        self.water_lineEdit_lcd_7.setObjectName(_fromUtf8("water_lineEdit_lcd_7"))

        #水模体部分布局，设置各部件位置大小
        self.gridLayout_water.addWidget(self.water_pushButton, 0, 2, 1, 2)
        self.gridLayout_water.addWidget(self.water_label_CT, 1, 0, 1, 2)
        self.gridLayout_water.addWidget(self.water_lineEdit_CT, 1, 2, 1, 2)
        self.gridLayout_water.addWidget(self.water_label_noise, 2, 0, 1, 2)
        self.gridLayout_water.addWidget(self.water_lineEdit_noise, 2, 2, 1, 2)
        self.gridLayout_water.addWidget(self.water_label_junyun, 3, 0, 1, 2)
        self.gridLayout_water.addWidget(self.water_lineEdit_junyun, 3, 2, 1, 2)
        self.gridLayout_water.addWidget(self.water_label_lcd, 4, 0, 1, 3)
        self.gridLayout_water.addWidget(self.water_label_lcd_2, 5, 0, 1, 1)
        self.gridLayout_water.addWidget(self.water_label_lcd_3, 5, 2, 1, 1)
        self.gridLayout_water.addWidget(self.water_label_lcd_5, 6, 0, 1, 1)
        self.gridLayout_water.addWidget(self.water_label_lcd_7, 6, 2, 1, 1)
        self.gridLayout_water.addWidget(self.water_lineEdit_lcd_2, 5, 1, 1, 1)
        self.gridLayout_water.addWidget(self.water_lineEdit_lcd_3, 5, 3, 1, 1)
        self.gridLayout_water.addWidget(self.water_lineEdit_lcd_5, 6, 1, 1, 1)
        self.gridLayout_water.addWidget(self.water_lineEdit_lcd_7, 6, 3, 1, 1)
        self.gridLayout_all.addWidget(self.groupBox_water, 0, 0, 1, 1)




        # CT线性值
        self.groupBox_linear = QtGui.QGroupBox(self.widget)#CT线性值框
        self.gridLayout_linear = QtGui.QGridLayout(self.groupBox_linear)
        self.linear_pushButton = QtGui.QPushButton(self.groupBox_linear)      #测量CT值计算按钮
        self.linear_label_celiang = QtGui.QLabel(self.groupBox_linear)                #八种材料的测量CT值标签
        self.linear_lineEdit_ctceliang1 = QtGui.QLineEdit(self.groupBox_linear)#材料一CT测量值编辑框
        self.linear_lineEdit_ctceliang2 = QtGui.QLineEdit(self.groupBox_linear)#材料二CT测量值编辑框
        self.linear_lineEdit_ctceliang3 = QtGui.QLineEdit(self.groupBox_linear)#材料三CT测量值编辑框
        self.linear_lineEdit_ctceliang4 = QtGui.QLineEdit(self.groupBox_linear)#材料四CT测量值编辑框
        self.linear_lineEdit_ctceliang5 = QtGui.QLineEdit(self.groupBox_linear)#材料五CT测量值编辑框
        self.linear_lineEdit_ctceliang6 = QtGui.QLineEdit(self.groupBox_linear)#材料六CT测量值编辑框
        self.linear_lineEdit_ctceliang7 = QtGui.QLineEdit(self.groupBox_linear)#材料七CT测量值编辑框
        self.linear_lineEdit_ctceliang8 = QtGui.QLineEdit(self.groupBox_linear)#材料八CT测量值编辑框
        self.linear_label_lilun = QtGui.QLabel(self.groupBox_linear)               #八种材料的理论CT值标签
        self.checkbox1 = QtGui.QCheckBox(self.groupBox_linear)#材料一理论值勾选框
        self.linear_lineEdit_ctlilun1 = QtGui.QLineEdit(self.groupBox_linear)#材料一CT理论值编辑框
        #self.linear_lineEdit_ctlilun1.setReadOnly(True)
        self.linear_lineEdit_ctlilun1.setEnabled(False)
        self.checkbox2 = QtGui.QCheckBox(self.groupBox_linear)#材料二理论值勾选框
        self.linear_lineEdit_ctlilun2 = QtGui.QLineEdit(self.groupBox_linear)#材料二CT理论值编辑框
        #self.linear_lineEdit_ctlilun2.setReadOnly(True)
        self.linear_lineEdit_ctlilun2.setEnabled(False)
        self.checkbox3 = QtGui.QCheckBox(self.groupBox_linear)#材料三理论值勾选框
        self.linear_lineEdit_ctlilun3 = QtGui.QLineEdit(self.groupBox_linear)#材料三CT理论值编辑框
        #self.linear_lineEdit_ctlilun3.setReadOnly(True)
        self.linear_lineEdit_ctlilun3.setEnabled(False)
        self.checkbox4 = QtGui.QCheckBox(self.groupBox_linear)#材料四理论值勾选框
        self.linear_lineEdit_ctlilun4 = QtGui.QLineEdit(self.groupBox_linear)#材料四CT理论值编辑框
        #self.linear_lineEdit_ctlilun4.setReadOnly(True)
        self.linear_lineEdit_ctlilun4.setEnabled(False)
        self.checkbox5 = QtGui.QCheckBox(self.groupBox_linear)#材料五理论值勾选框
        self.linear_lineEdit_ctlilun5 = QtGui.QLineEdit(self.groupBox_linear)#材料五CT理论值编辑框
        #self.linear_lineEdit_ctlilun5.setReadOnly(True)
        self.linear_lineEdit_ctlilun5.setEnabled(False)
        self.checkbox6 = QtGui.QCheckBox(self.groupBox_linear)#材料六理论值勾选框
        self.linear_lineEdit_ctlilun6 = QtGui.QLineEdit(self.groupBox_linear)#材料六CT理论值编辑框
        #self.linear_lineEdit_ctlilun6.setReadOnly(True)
        self.linear_lineEdit_ctlilun6.setEnabled(False)
        self.checkbox7 = QtGui.QCheckBox(self.groupBox_linear)#材料七理论值勾选框
        self.linear_lineEdit_ctlilun7 = QtGui.QLineEdit(self.groupBox_linear)#材料七CT理论值编辑框
        #self.linear_lineEdit_ctlilun7.setReadOnly(True)
        self.linear_lineEdit_ctlilun7.setEnabled(False)
        self.checkbox8 = QtGui.QCheckBox(self.groupBox_linear)#材料八理论值勾选框
        self.linear_lineEdit_ctlilun8 = QtGui.QLineEdit(self.groupBox_linear)#材料八CT理论值编辑框
        #self.linear_lineEdit_ctlilun8.setReadOnly(True)
        self.linear_lineEdit_ctlilun8.setEnabled(False)
        self.pushButton_ctxianxing = QtGui.QPushButton(self.groupBox_linear)#计算CT线性值按钮
        #self.pushButton_ctxianxing.setDisabled(True)
        self.linear_label_CT = QtGui.QLabel(self.groupBox_linear)#CT线性值标签
        self.linear_lineEdit_CT = QtGui.QLineEdit(self.groupBox_linear)#CT线性值编辑框
        
        


        #CT线性值部件命名
        self.groupBox_linear.setObjectName(_fromUtf8("groupBox_linear"))
        self.gridLayout_linear.setObjectName(_fromUtf8("gridLayout_linear"))
        self.linear_pushButton.setObjectName(_fromUtf8("linear_pushButton"))
        self.linear_label_celiang.setObjectName(_fromUtf8("linear_label_celiang"))
        self.linear_lineEdit_ctceliang1.setObjectName(_fromUtf8("linear_lineEdit_ctceliang1"))
        self.linear_lineEdit_ctceliang2.setObjectName(_fromUtf8("linear_lineEdit_ctceliang2"))
        self.linear_lineEdit_ctceliang3.setObjectName(_fromUtf8("linear_lineEdit_ctceliang3"))
        self.linear_lineEdit_ctceliang4.setObjectName(_fromUtf8("linear_lineEdit_ctceliang4"))
        self.linear_lineEdit_ctceliang5.setObjectName(_fromUtf8("linear_lineEdit_ctceliang5"))
        self.linear_lineEdit_ctceliang6.setObjectName(_fromUtf8("linear_lineEdit_ctceliang6"))
        self.linear_lineEdit_ctceliang7.setObjectName(_fromUtf8("linear_lineEdit_ctceliang7"))
        self.linear_lineEdit_ctceliang8.setObjectName(_fromUtf8("linear_lineEdit_ctceliang8"))
        self.linear_label_lilun.setObjectName(_fromUtf8("linear_label_lilun"))
        self.checkbox1.setObjectName(_fromUtf8("checkbox1"))
        self.linear_lineEdit_ctlilun1.setObjectName(_fromUtf8("linear_lineEdit_ctlilun1"))
        self.checkbox2.setObjectName(_fromUtf8("checkbox2"))
        self.linear_lineEdit_ctlilun2.setObjectName(_fromUtf8("linear_lineEdit_ctlilun2"))
        self.checkbox3.setObjectName(_fromUtf8("checkbox3"))
        self.linear_lineEdit_ctlilun3.setObjectName(_fromUtf8("linear_lineEdit_ctlilun3"))
        self.checkbox4.setObjectName(_fromUtf8("checkbox4"))
        self.linear_lineEdit_ctlilun4.setObjectName(_fromUtf8("linear_lineEdit_ctlilun4"))
        self.linear_lineEdit_ctlilun5.setObjectName(_fromUtf8("linear_lineEdit_ctlilun5"))
        self.checkbox5.setObjectName(_fromUtf8("checkbox5"))
        self.checkbox6.setObjectName(_fromUtf8("checkbox6"))
        self.linear_lineEdit_ctlilun6.setObjectName(_fromUtf8("linear_lineEdit_ctlilun6"))
        self.checkbox7.setObjectName(_fromUtf8("checkbox7"))
        self.linear_lineEdit_ctlilun7.setObjectName(_fromUtf8("linear_lineEdit_ctlilun7"))
        self.checkbox8.setObjectName(_fromUtf8("checkbox8"))
        self.linear_lineEdit_ctlilun8.setObjectName(_fromUtf8("linear_lineEdit_ctlilun8"))
        self.pushButton_ctxianxing.setObjectName(_fromUtf8("pushButton_ctxianxing"))
        self.linear_label_CT.setObjectName(_fromUtf8("linear_label_CT"))
        self.linear_lineEdit_CT.setObjectName(_fromUtf8("linear_lineEdit_CT"))
        #CT线性值部分布局，设置大小和位置
        self.gridLayout_linear.addWidget(self.linear_pushButton, 1, 6, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_label_celiang, 1, 0, 1, 6)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang1, 2, 0, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang2, 2, 2, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang3, 2, 4, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang4, 2, 6, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang5, 3, 0, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang6, 3, 2, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang7, 3, 4, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctceliang8, 3, 6, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_label_lilun, 4, 0, 1, 6)
        self.gridLayout_linear.addWidget(self.checkbox1, 5, 0, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun1, 5, 1, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox2, 5, 2, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun2, 5, 3, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox3, 5, 4, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun3, 5, 5, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox4, 5, 6, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun4, 5, 7, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox5, 6, 0, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun5, 6, 1, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox6, 6, 2, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun6, 6, 3, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox7, 6, 4, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun7, 6, 5, 1, 1)
        self.gridLayout_linear.addWidget(self.checkbox8, 6, 6, 1, 1)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_ctlilun8, 6, 7, 1, 1)
        self.gridLayout_linear.addWidget(self.pushButton_ctxianxing, 8, 6, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_label_CT, 8, 0, 1, 2)
        self.gridLayout_linear.addWidget(self.linear_lineEdit_CT, 8, 2, 1, 2)
        self.gridLayout_all.addWidget(self.groupBox_linear, 0, 1, 1, 1)
        #CT线性理论值编辑框中填入self.ctLilunDef的内容
        self.linear_lineEdit_ctlilun1.setText("%.3f"%self.ctLilunDef[0])
        self.linear_lineEdit_ctlilun2.setText("%.3f"%self.ctLilunDef[1])
        self.linear_lineEdit_ctlilun3.setText("%.3f"%self.ctLilunDef[2])
        self.linear_lineEdit_ctlilun4.setText("%.3f"%self.ctLilunDef[3])
        self.linear_lineEdit_ctlilun5.setText("%.3f"%self.ctLilunDef[4])
        self.linear_lineEdit_ctlilun6.setText("%.3f"%self.ctLilunDef[5])
        self.linear_lineEdit_ctlilun7.setText("%.3f"%self.ctLilunDef[6])
        self.linear_lineEdit_ctlilun8.setText("%.3f"%self.ctLilunDef[7])



        #层厚偏差
        self.groupBox_sliceThickness = QtGui.QGroupBox(self.widget)#层厚偏差框
        self.gridLayout_sliceThickness = QtGui.QGridLayout(self.groupBox_sliceThickness)
        self.label_cenghou8 = QtGui.QLabel(self.groupBox_sliceThickness)     #cenghou >=8   
        #self.label_cenghou8.setObjectName(_fromUtf8("label_cenghou8"))
        #self.label_cenghou8.setText(_translate("Viewer", "S>=8mm", None))
        #self.gridLayout_sliceThickness.addWidget(self.label_cenghou8, 0, 0, 1, 1)
        
        self.sliceThickness_pushButton_8 = QtGui.QPushButton(self.groupBox_sliceThickness)#层厚>=8处计算按钮
        self.sliceThickness_label_bc8 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚>=8处标称值标签
        self.sliceThickness_lineEdit_bc8 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚>=8处标称值编辑框
        self.sliceThickness_label_shice8 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚>=8处实测值标签
        self.sliceThickness_lineEdit_shice8 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚>=8处实测值编辑框
        self.sliceThickness_label_error8 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚>=8处相对误差标签
        self.sliceThickness_lineEdit_error8 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚>=8处相对误差编辑框
        self.label_cenghou28 = QtGui.QLabel(self.groupBox_sliceThickness)     # 2 <= cenghou < 8
        #self.label_cenghou28.setObjectName(_fromUtf8("label_cenghou28"))
        #self.label_cenghou28.setText(_translate("Viewer", "2mm<=S<8mm", None))
        #self.gridLayout_sliceThickness.addWidget(self.label_cenghou28, 4, 0, 1, 1)
        self.sliceThickness_pushButton_28 = QtGui.QPushButton(self.groupBox_sliceThickness)#2<=层厚<8处计算按钮
        self.sliceThickness_label_bc28 = QtGui.QLabel(self.groupBox_sliceThickness)#2<=层厚<8处标称值标签
        self.sliceThickness_lineEdit_bc28 = QtGui.QLineEdit(self.groupBox_sliceThickness)#2<=层厚<8处标称值编辑框
        self.sliceThickness_label_shice28 = QtGui.QLabel(self.groupBox_sliceThickness)#2<=层厚<8处实测值标签
        self.sliceThickness_lineEdit_shice28 = QtGui.QLineEdit(self.groupBox_sliceThickness)#2<=层厚<8处实测值编辑框
        self.sliceThickness_label_error28 = QtGui.QLabel(self.groupBox_sliceThickness)#2<=层厚<8处相对误差标签
        self.sliceThickness_lineEdit_error28 = QtGui.QLineEdit(self.groupBox_sliceThickness)#2<=层厚<8处相对误差编辑框
        self.label_cenghou2 = QtGui.QLabel(self.groupBox_sliceThickness)     #cenghou < 2
        #self.label_cenghou2.setObjectName(_fromUtf8("label_cenghou2"))
        #self.label_cenghou2.setText(_translate("Viewer", "1<=S<2mm", None))
        #self.gridLayout_sliceThickness.addWidget(self.label_cenghou2, 8, 0, 1, 1)
        self.sliceThickness_pushButton_2 = QtGui.QPushButton(self.groupBox_sliceThickness)#层厚<2处计算按钮
        #self.sliceThickness_pushButton_2.setDisabled(True)
        self.sliceThickness_label_bc2 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚<2处标称值标签
        self.sliceThickness_lineEdit_bc2 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚<2处标称值编辑框
        self.sliceThickness_label_shice2 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚<2处实测值标签
        self.sliceThickness_lineEdit_shice2 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚<2处实测值编辑框
        self.sliceThickness_label_error2 = QtGui.QLabel(self.groupBox_sliceThickness)#层厚<2处相对误差标签
        self.sliceThickness_lineEdit_error2 = QtGui.QLineEdit(self.groupBox_sliceThickness)#层厚<2处相对误差编辑框
        
        
        
        #层厚偏差部分命名
        self.groupBox_sliceThickness.setObjectName(_fromUtf8("groupBox_sliceThickness"))
        self.gridLayout_sliceThickness.setObjectName(_fromUtf8("gridLayout_sliceThickness"))
        self.sliceThickness_pushButton_8.setObjectName(_fromUtf8("sliceThickness_pushButton_8"))
        self.sliceThickness_label_bc8.setObjectName(_fromUtf8("sliceThickness_label_bc8"))
        self.sliceThickness_lineEdit_bc8.setObjectName(_fromUtf8("sliceThickness_lineEdit_bc8"))
        self.sliceThickness_label_shice8.setObjectName(_fromUtf8("sliceThickness_label_shice8"))
        self.sliceThickness_lineEdit_shice8.setObjectName(_fromUtf8("sliceThickness_lineEdit_shice8"))
        self.sliceThickness_label_error8.setObjectName(_fromUtf8("sliceThickness_label_error8"))
        self.sliceThickness_lineEdit_error8.setObjectName(_fromUtf8("sliceThickness_lineEdit_error8"))
        self.sliceThickness_pushButton_28.setObjectName(_fromUtf8("sliceThickness_pushButton_28"))
        self.sliceThickness_label_bc28.setObjectName(_fromUtf8("sliceThickness_label_bc28"))
        self.sliceThickness_lineEdit_bc28.setObjectName(_fromUtf8("sliceThickness_lineEdit_bc28"))
        self.sliceThickness_label_shice28.setObjectName(_fromUtf8("sliceThickness_label_shice28"))
        self.sliceThickness_lineEdit_shice28.setObjectName(_fromUtf8("sliceThickness_lineEdit_shice28"))
        self.sliceThickness_label_error28.setObjectName(_fromUtf8("sliceThickness_label_error28"))
        self.sliceThickness_lineEdit_error28.setObjectName(_fromUtf8("sliceThickness_lineEdit_error28"))
        self.sliceThickness_pushButton_2.setObjectName(_fromUtf8("sliceThickness_pushButton_2"))
        self.sliceThickness_label_bc2.setObjectName(_fromUtf8("sliceThickness_label_bc2"))
        self.sliceThickness_lineEdit_bc2.setObjectName(_fromUtf8("sliceThickness_lineEdit_bc2"))
        self.sliceThickness_label_shice2.setObjectName(_fromUtf8("sliceThickness_label_shice2"))
        self.sliceThickness_lineEdit_shice2.setObjectName(_fromUtf8("sliceThickness_lineEdit_shice2"))
        self.sliceThickness_label_error2.setObjectName(_fromUtf8("sliceThickness_label_error2"))
        self.sliceThickness_lineEdit_error2.setObjectName(_fromUtf8("sliceThickness_lineEdit_error2"))
        #层厚偏差部分布局安排，设置大小位置

        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_pushButton_8, 0, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_bc8, 1, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_bc8, 1, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_shice8, 2, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_shice8, 2, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_error8, 3, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_error8, 3, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_pushButton_28, 4, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_bc28, 5, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_bc28, 5, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_shice28, 6, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_shice28, 6, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_error28, 7, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_error28, 7, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_pushButton_2, 8, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_bc2, 9, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_bc2, 9, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_shice2, 10, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_shice2, 10, 2, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_label_error2, 11, 0, 1, 1)
        self.gridLayout_sliceThickness.addWidget(self.sliceThickness_lineEdit_error2, 11, 2, 1, 1)
        self.gridLayout_all.addWidget(self.groupBox_sliceThickness, 1, 0, 3, 1)
        
        # 高对比分辨力
        self.groupBox_resolution = QtGui.QGroupBox(self.widget)#高对比分辨力框
        self.gridLayout_resolution = QtGui.QGridLayout(self.groupBox_resolution)#高对比分辨力布局
        #self.pushButton_5 = QtGui.QPushButton(self.groupBox_resolution)
        #self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))
        #self.gridLayout_resolution.addWidget(self.pushButton_5, 0, 2, 1, 2)
        self.resolution_label_x = QtGui.QLabel(self.groupBox_resolution)#识别钨珠位置x坐标标签
        self.resolution_label_changgui = QtGui.QLabel(self.groupBox_resolution)#常规算法标签
        self.resolution_label_gaofenbian = QtGui.QLabel(self.groupBox_resolution)#高分辨算法标签
        self.resolution_label_y = QtGui.QLabel(self.groupBox_resolution)#识别钨珠位置y坐标标签
        self.resolution_lineEdit_y = QtGui.QLineEdit(self.groupBox_resolution)#识别钨珠位置y坐标编辑框
        self.resolution_lineEdit_x = QtGui.QLineEdit(self.groupBox_resolution)#识别钨珠位置x坐标编辑框
        #self.lineEdit_35 = QtGui.QLineEdit(self.groupBox_resolution)
        #self.lineEdit_35.setObjectName(_fromUtf8("lineEdit_35"))
       # self.gridLayout_resolution.addWidget(self.lineEdit_35, 1, 3, 1, 1)
        self.resolution_pushButton_1 = QtGui.QPushButton(self.groupBox_resolution)#常规算法计算按钮
        self.resolution_pushButton_2 = QtGui.QPushButton(self.groupBox_resolution)#高分辨算法计算按钮
        self.resolution_lineEdit_C_10 = QtGui.QLineEdit(self.groupBox_resolution)#常规算法，10%编辑框
        self.resolution_lineEdit_G_10 = QtGui.QLineEdit(self.groupBox_resolution)#高分辨算法，10%编辑框
        self.resolution_label_C_10 = QtGui.QLabel(self.groupBox_resolution)#常规算法10%标签
        self.resolution_label_G_10 = QtGui.QLabel(self.groupBox_resolution)#高分辨算法10%标签
        self.resolution_label_G_50 = QtGui.QLabel(self.groupBox_resolution)#高分辨算法50%标签
        self.resolution_label_C_50 = QtGui.QLabel(self.groupBox_resolution)#常规算法50%标签
        self.resolution_lineEdit_C_50 = QtGui.QLineEdit(self.groupBox_resolution)#常规算法，50%编辑框
        self.resolution_lineEdit_G_50 = QtGui.QLineEdit(self.groupBox_resolution)#高分辨算法，50%编辑框
        
        

        
        #高对比分辨力部分命名
        self.groupBox_resolution.setObjectName(_fromUtf8("groupBox_resolution"))
        self.gridLayout_resolution.setObjectName(_fromUtf8("gridLayout_resolution"))
        self.resolution_label_x.setObjectName(_fromUtf8("resolution_label_x"))
        self.resolution_label_changgui.setObjectName(_fromUtf8("resolution_label_changgui"))
        self.resolution_label_gaofenbian.setObjectName(_fromUtf8("resolution_label_gaofenbian"))
        self.resolution_label_y.setObjectName(_fromUtf8("resolution_label_y"))
        self.resolution_lineEdit_y.setObjectName(_fromUtf8("resolution_lineEdit_y"))
        self.resolution_lineEdit_x.setObjectName(_fromUtf8("resolution_lineEdit_x"))
        self.resolution_pushButton_1.setObjectName(_fromUtf8("resolution_pushButton_1"))
        self.resolution_pushButton_2.setObjectName(_fromUtf8("resolution_pushButton_2"))
        self.resolution_lineEdit_C_10.setObjectName(_fromUtf8("resolution_lineEdit_C_10"))
        self.resolution_lineEdit_G_10.setObjectName(_fromUtf8("resolution_lineEdit_G_10"))
        self.resolution_label_C_10.setObjectName(_fromUtf8("resolution_label_C_10"))
        self.resolution_label_G_10.setObjectName(_fromUtf8("resolution_label_G_10"))
        self.resolution_label_G_50.setObjectName(_fromUtf8("resolution_label_G_50"))
        self.resolution_label_C_50.setObjectName(_fromUtf8("resolution_label_C_50"))
        self.resolution_lineEdit_C_50.setObjectName(_fromUtf8("resolution_lineEdit_C_50"))
        self.resolution_lineEdit_G_50.setObjectName(_fromUtf8("resolution_lineEdit_G_50"))
        #高对比分辨力部分布局，设置大小和位置
        self.gridLayout_resolution.addWidget(self.resolution_label_x, 0, 0, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_changgui, 1, 0, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_gaofenbian, 1, 2, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_y, 0, 2, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_y, 0, 3, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_x, 0, 1, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_pushButton_1, 1, 1, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_pushButton_2, 1, 3, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_C_10, 2, 1, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_G_10, 2, 3, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_C_10, 2, 0, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_G_10, 2, 2, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_G_50, 3, 2, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_label_C_50, 3, 0, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_C_50, 3, 1, 1, 1)
        self.gridLayout_resolution.addWidget(self.resolution_lineEdit_G_50, 3, 3, 1, 1)
        self.gridLayout_all.addWidget(self.groupBox_resolution, 1, 1, 1, 1)
        #高对比分辨力部分  标签填入内容
        self.resolution_label_changgui.setText(_translate("groupBox_sliceThickness", "常规算法", None))
        self.resolution_label_gaofenbian.setText(_translate("groupBox_sliceThickness", "高分辨算法", None))
        self.resolution_label_y.setText(_translate("groupBox_sliceThickness", "钨珠中心(y)", None))
        self.resolution_pushButton_2.setText(_translate("groupBox_sliceThickness", "计算", None))
        self.resolution_label_G_50.setText(_translate("groupBox_sliceThickness", "50%", None))
        self.resolution_label_C_50.setText(_translate("groupBox_sliceThickness", "50%", None))


        # CT剂量指数
        self.groupBox_5 = QtGui.QGroupBox(self.widget)
        self.gridLayout_7 = QtGui.QGridLayout(self.groupBox_5)
        self.pushButton_head = QtGui.QPushButton(self.groupBox_5)#头部模体计算按钮
        self.label_head_ceter = QtGui.QLabel(self.groupBox_5)#头部模体中心标签
        self.label_head = QtGui.QLabel(self.groupBox_5)#头部模体标签
        self.label_body = QtGui.QLabel(self.groupBox_5)#体部模体标签
        self.label_head_0 = QtGui.QLabel(self.groupBox_5)#头部模体下0标签
        self.label_head_3 = QtGui.QLabel(self.groupBox_5)#头部模体下3标签
        self.label_head_6 = QtGui.QLabel(self.groupBox_5)#头部模体下6标签
        self.label_head_9 = QtGui.QLabel(self.groupBox_5)#头部模体下9标签
        self.label_head_CTDIw = QtGui.QLabel(self.groupBox_5)#头部模体CTDIw标签
        self.lineEdit_head_center = QtGui.QLineEdit(self.groupBox_5)#头部模体中心编辑框
        self.lineEdit_head_0 = QtGui.QLineEdit(self.groupBox_5)#头部模体下0编辑框
        self.lineEdit_head_3 = QtGui.QLineEdit(self.groupBox_5)#头部模体下3编辑框
        self.lineEdit_head_6 = QtGui.QLineEdit(self.groupBox_5)#头部模体下6编辑框
        self.lineEdit_head_9 = QtGui.QLineEdit(self.groupBox_5)#头部模体下9编辑框
        self.lineEdit_head_CTDIw = QtGui.QLineEdit(self.groupBox_5)#头部模体CTDIw编辑框
        self.pushButton_body = QtGui.QPushButton(self.groupBox_5)#体部模体计算按钮
        self.label_body_ceter = QtGui.QLabel(self.groupBox_5)#体部模体中心标签
        self.label_body_0 = QtGui.QLabel(self.groupBox_5)#体部模体下0标签
        self.label_body_3 = QtGui.QLabel(self.groupBox_5)#体部模体下3标签
        self.label_body_6 = QtGui.QLabel(self.groupBox_5)#体部模体下6标签
        self.label_body_9 = QtGui.QLabel(self.groupBox_5)#体部模体下9标签
        self.label_body_CTDIw = QtGui.QLabel(self.groupBox_5)#体部模体CTDIw标签
        self.lineEdit_body_center = QtGui.QLineEdit(self.groupBox_5)#体部模体中心编辑框
        self.lineEdit_body_0 = QtGui.QLineEdit(self.groupBox_5)#体部模体下0编辑框
        self.lineEdit_body_3 = QtGui.QLineEdit(self.groupBox_5)#体部模体下3编辑框
        self.lineEdit_body_6 = QtGui.QLineEdit(self.groupBox_5)#体部模体下6编辑框
        self.lineEdit_body_9 = QtGui.QLineEdit(self.groupBox_5)#体部模体下9编辑框
        self.lineEdit_body_CTDIw = QtGui.QLineEdit(self.groupBox_5)#体部模体CTDIw编辑框
        
        
        #CT计量指数命名
        self.groupBox_5.setObjectName(_fromUtf8("groupBox_5"))
        self.gridLayout_7.setObjectName(_fromUtf8("gridLayout_7"))
        self.pushButton_head.setObjectName(_fromUtf8("pushButton_head"))
        self.label_head_ceter.setObjectName(_fromUtf8("label_head_ceter"))
        self.label_head.setObjectName(_fromUtf8("label_head"))
        self.label_body.setObjectName(_fromUtf8("label_body"))
        self.label_head_0.setObjectName(_fromUtf8("label_head_0"))
        self.label_head_3.setObjectName(_fromUtf8("label_head_3"))
        self.label_head_6.setObjectName(_fromUtf8("label_head_6"))
        self.label_head_9.setObjectName(_fromUtf8("label_head_9"))
        self.label_head_CTDIw.setObjectName(_fromUtf8("label_head_CTDIw"))
        self.lineEdit_head_center.setObjectName(_fromUtf8("lineEdit_head_center"))
        self.lineEdit_head_0.setObjectName(_fromUtf8("lineEdit_head_0"))
        self.lineEdit_head_3.setObjectName(_fromUtf8("lineEdit_head_3"))
        self.lineEdit_head_6.setObjectName(_fromUtf8("lineEdit_head_6"))
        self.lineEdit_head_9.setObjectName(_fromUtf8("lineEdit_head_9"))
        self.lineEdit_head_CTDIw.setObjectName(_fromUtf8("lineEdit_head_CTDIw"))
        self.pushButton_body.setObjectName(_fromUtf8("pushButton_body"))
        self.label_body_ceter.setObjectName(_fromUtf8("label_body_ceter"))
        self.label_body_0.setObjectName(_fromUtf8("label_body_0"))
        self.label_body_3.setObjectName(_fromUtf8("label_body_3"))
        self.label_body_6.setObjectName(_fromUtf8("label_body_6"))
        self.label_body_9.setObjectName(_fromUtf8("label_body_9"))
        self.label_body_CTDIw.setObjectName(_fromUtf8("label_body_CTDIw"))
        self.lineEdit_body_center.setObjectName(_fromUtf8("lineEdit_body_center"))
        self.lineEdit_body_0.setObjectName(_fromUtf8("lineEdit_body_0"))
        self.lineEdit_body_3.setObjectName(_fromUtf8("lineEdit_body_3"))
        self.lineEdit_body_6.setObjectName(_fromUtf8("lineEdit_body_6"))
        self.lineEdit_body_9.setObjectName(_fromUtf8("lineEdit_body_9"))
        self.lineEdit_body_CTDIw.setObjectName(_fromUtf8("lineEdit_head_CTDIw"))



        
        #CT剂量指数布局，设置大小位置
        self.gridLayout_7.addWidget(self.pushButton_head, 0, 1, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_ceter, 1, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_head, 0, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_body, 0, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_0, 2, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_3, 3, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_6, 4, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_9, 5, 0, 1, 1)
        self.gridLayout_7.addWidget(self.label_head_CTDIw, 6, 0, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_center, 1, 1, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_0, 2, 1, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_3, 3, 1, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_6, 4, 1, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_9, 5, 1, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_head_CTDIw, 6, 1, 1, 1)
        self.gridLayout_7.addWidget(self.pushButton_body, 0, 3, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_ceter, 1, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_0, 2, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_3, 3, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_6, 4, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_9, 5, 2, 1, 1)
        self.gridLayout_7.addWidget(self.label_body_CTDIw, 6, 2, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_center, 1, 3, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_0, 2, 3, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_3, 3, 3, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_6, 4, 3, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_9, 5, 3, 1, 1)
        self.gridLayout_7.addWidget(self.lineEdit_body_CTDIw, 6, 3, 1, 1)
        self.gridLayout_all.addWidget(self.groupBox_5, 2, 1, 2, 1)
        #set text
        self.label_head.setText(_translate("groupBox_5", "头部模体", None))
        self.label_body.setText(_translate("groupBox_5", "体部模体", None))


        '''
        # 图像信息
        self.groupBox_imageInfo = QtGui.QGroupBox(self.widget)
        self.groupBox_imageInfo.setObjectName(_fromUtf8("groupBox_imageInfo"))
        self.gridLayout_imageInfo = QtGui.QGridLayout(self.groupBox_imageInfo)
        self.gridLayout_imageInfo.setObjectName(_fromUtf8("gridLayout_imageInfo"))
        self.groupBox_imageInfo.setTitle(_translate("Viewer", "图像基本信息", None))
        self.label_dcmKVP = QtGui.QLabel(self.groupBox_imageInfo)
        self.label_dcmKVP.setObjectName(_fromUtf8("label_dcmKVP"))
        self.label_dcmKVP.setText(_translate("Viewer", "电压值(kV)", None))
        self.gridLayout_imageInfo.addWidget(self.label_dcmKVP, 0, 0, 1, 1)
        self.lineEdit_dcmKVP = QtGui.QLineEdit(self.groupBox_imageInfo)
        self.lineEdit_dcmKVP.setObjectName(_fromUtf8("lineEdit_dcmKVP"))
        self.lineEdit_dcmKVP.setEnabled(False)
        self.gridLayout_imageInfo.addWidget(self.lineEdit_dcmKVP, 0, 1, 1, 1)
        self.label_dcmXRayTubeCurrent = QtGui.QLabel(self.groupBox_imageInfo)
        self.label_dcmXRayTubeCurrent.setObjectName(_fromUtf8("label_dcmXRayTubeCurrent"))
        self.label_dcmXRayTubeCurrent.setText(_translate("Viewer", "电流值(mA)", None))
        self.gridLayout_imageInfo.addWidget(self.label_dcmXRayTubeCurrent, 0, 2, 1, 1)
        self.lineEdit_dcmXRayTubeCurrent = QtGui.QLineEdit(self.groupBox_imageInfo)
        self.lineEdit_dcmXRayTubeCurrent.setObjectName(_fromUtf8("lineEdit_dcmXRayTubeCurrent"))
        self.lineEdit_dcmXRayTubeCurrent.setEnabled(False)
        self.gridLayout_imageInfo.addWidget(self.lineEdit_dcmXRayTubeCurrent, 0, 3, 1, 1)
        self.label_dcmExposureTime = QtGui.QLabel(self.groupBox_imageInfo)
        self.label_dcmExposureTime.setObjectName(_fromUtf8("label_dcmExposureTime"))
        self.label_dcmExposureTime.setText(_translate("Viewer", "曝光时间(ms)", None))
        self.gridLayout_imageInfo.addWidget(self.label_dcmExposureTime, 1, 0, 1, 1)
        self.lineEdit_dcmExposureTime = QtGui.QLineEdit(self.groupBox_imageInfo)
        self.lineEdit_dcmExposureTime.setObjectName(_fromUtf8("lineEdit_dcmExposureTime"))
        self.lineEdit_dcmExposureTime.setEnabled(False)
        self.gridLayout_imageInfo.addWidget(self.lineEdit_dcmExposureTime, 1, 1, 1, 1)

        self.gridLayout_all.addWidget(self.groupBox_imageInfo, 2, 1, 1, 1)
        '''

        # self.setCentralWidget(self.pix_label)
        self.setCentralWidget(scroll_area)

        self.file_dock = QtWidgets.QDockWidget("Files", self)#文件停靠
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, self.file_dock)

        self.file_list = QtWidgets.QListWidget()#文件列表
        self.file_list.itemSelectionChanged.connect(self.on_file_item_change)#当列表中选择文件切换时调用self.on_file_item_change
        self.file_dock.setWidget(self.file_list)

        self.hu_label = QtWidgets.QLabel("No image")
        self.c_label = QtWidgets.QLabel("")
        self.cw_label = QtWidgets.QLabel("")
        self.x_label = QtWidgets.QLabel("")
        self.y_label = QtWidgets.QLabel("")
        self.z_label = QtWidgets.QLabel("")
        self.use_fractional_coordinates = True#使用分数坐标
        self.ij_label = QtWidgets.QLabel("")

        self._zoom_level = 1
        self.mouse_x = -1
        self.mouse_y = -1
        #填入对应标签名称
        self.pushButton_report.setText(_translate("", "生成报告", None))
        self.groupBox_water.setTitle(_translate("Viewer", "水模体指标", None))

        self.water_pushButton.setText(_translate("Viewer", "计算", None))
        self.water_label_CT.setText(_translate("Viewer", "CT值(水)", None))
        self.water_label_noise.setText(_translate("Viewer", "噪声(%)", None))
        self.water_label_junyun.setText(_translate("Viewer", "均匀性(HU)", None))
        self.water_label_lcd.setText(_translate("Viewer", "低对比可探测能力", None))
        self.water_label_lcd_2.setText(_translate("Viewer", "2", None))
        self.water_label_lcd_3.setText(_translate("Viewer", "3", None))
        self.water_label_lcd_5.setText(_translate("Viewer", "5", None))
        self.water_label_lcd_7.setText(_translate("Viewer", "7", None))
        self.groupBox_linear.setTitle(_translate("Viewer", "CT线性值", None))

        self.linear_pushButton.setText(_translate("Viewer", "计算", None))
        self.linear_label_celiang.setText(_translate("Viewer", "八种材料的测量CT值", None))
        self.linear_label_lilun.setText(_translate("Viewer", "八种材料的理论CT值(用户输入)", None))
        self.pushButton_ctxianxing.setText(_translate("Viewer", "计算CT线性值", None))
        self.linear_label_CT.setText(_translate("Viewer", "CT线性值", None))
        self.groupBox_sliceThickness.setTitle(_translate("Viewer", "层厚偏差(%)", None))
        self.label_diam.setText(_translate("Viewer", "螺旋珠直径", None))
        self.label_pitch.setText(_translate("Viewer", "螺距", None))
        self.label_diammm.setText(_translate("Viewer", "mm", None))
        self.label_pitchmm.setText(_translate("Viewer", "mm", None))
        self.label_num.setText(_translate("Viewer", "螺旋珠数量", None))
        
        
        
        self.sliceThickness_pushButton_8.setText(_translate("Viewer", "计算", None))
        self.sliceThickness_label_bc8.setText(_translate("Viewer", "层厚标称", None))
        self.sliceThickness_label_shice8.setText(_translate("Viewer", "层厚实测值", None))
        self.sliceThickness_label_error8.setText(_translate("Viewer", "相对误差(%)", None))
        self.sliceThickness_pushButton_28.setText(_translate("Viewer", "计算", None))
        self.sliceThickness_label_bc28.setText(_translate("Viewer", "层厚标称", None))
        self.sliceThickness_label_shice28.setText(_translate("Viewer", "层厚实测值", None))
        self.sliceThickness_label_error28.setText(_translate("Viewer", "相对误差(%)", None))
        self.sliceThickness_pushButton_2.setText(_translate("Viewer", "计算", None))
        self.sliceThickness_label_bc2.setText(_translate("Viewer", "层厚标称", None))
        self.sliceThickness_label_shice2.setText(_translate("Viewer", "层厚实测值", None))
        self.sliceThickness_label_error2.setText(_translate("Viewer", "相对误差(%)", None))
        self.groupBox_resolution.setTitle(_translate("Viewer", "高对比分辨力(LP/cm)", None))
        self.resolution_label_x.setText(_translate("Viewer", "钨珠中心(x)", None))
        self.resolution_pushButton_1.setText(_translate("Viewer", "计算", None))
        self.resolution_label_C_10.setText(_translate("Viewer", "10%", None))
        self.resolution_label_G_10.setText(_translate("Viewer", "10%", None))
       


        self.label_head_ceter.setText(_translate("Viewer", "中心", None))
        self.label_head_CTDIw.setText(_translate("Viewer", "CTDIw", None))
        self.label_head_0.setText(_translate("Viewer", "0", None))
        self.label_head_3.setText(_translate("Viewer", "3", None))
        self.label_head_6.setText(_translate("Viewer", "6", None))
        self.label_head_9.setText(_translate("Viewer", "9", None))
        self.pushButton_head.setText(_translate("Viewer", "计算", None))
        self.lineEdit_head_center.setPlaceholderText(u'(mGy)')
        self.lineEdit_head_CTDIw.setPlaceholderText(u'(mGy)')
        self.lineEdit_head_0.setPlaceholderText(u'(mGy)')
        self.lineEdit_head_3.setPlaceholderText(u'(mGy)')
        self.lineEdit_head_6.setPlaceholderText(u'(mGy)')
        self.lineEdit_head_9.setPlaceholderText(u'(mGy)')

        self.label_body_ceter.setText(_translate("Viewer", "中心", None))
        self.label_body_CTDIw.setText(_translate("Viewer", "CTDIw", None))
        self.label_body_0.setText(_translate("Viewer", "0", None))
        self.label_body_3.setText(_translate("Viewer", "3", None))
        self.label_body_6.setText(_translate("Viewer", "6", None))
        self.label_body_9.setText(_translate("Viewer", "9", None))
        self.pushButton_body.setText(_translate("Viewer", "计算", None))
        self.lineEdit_body_center.setPlaceholderText(u'(mGy)')
        self.lineEdit_body_CTDIw.setPlaceholderText(u'(mGy)')
        self.lineEdit_body_0.setPlaceholderText(u'(mGy)')
        self.lineEdit_body_3.setPlaceholderText(u'(mGy)')
        self.lineEdit_body_6.setPlaceholderText(u'(mGy)')
        self.lineEdit_body_9.setPlaceholderText(u'(mGy)')

        self.statusBar().addPermanentWidget(self.cw_label)#状态栏
        self.statusBar().addPermanentWidget(self.ij_label)
        self.statusBar().addPermanentWidget(self.x_label)
        self.statusBar().addPermanentWidget(self.y_label)
        self.statusBar().addPermanentWidget(self.z_label)
        self.statusBar().addPermanentWidget(self.hu_label)
        self.water_lineEdit_CT.setEnabled(0)
        self.water_lineEdit_noise.setEnabled(0)
        self.water_lineEdit_junyun.setEnabled(0)

        self.sliceThickness_lineEdit_bc8.setEnabled(0)
        self.sliceThickness_lineEdit_shice8.setEnabled(0)
        self.sliceThickness_lineEdit_error8.setEnabled(0)
        self.linear_lineEdit_ctceliang1.setEnabled(0)
        self.linear_lineEdit_ctceliang2.setEnabled(0)
        self.linear_lineEdit_ctceliang3.setEnabled(0)
        self.linear_lineEdit_ctceliang4.setEnabled(0)
        self.linear_lineEdit_ctceliang8.setEnabled(0)
        self.linear_lineEdit_ctceliang5.setEnabled(0)
        self.linear_lineEdit_ctceliang6.setEnabled(0)
        self.linear_lineEdit_ctceliang7.setEnabled(0)
        self.resolution_lineEdit_C_10.setEnabled(0)
        self.linear_lineEdit_CT.setEnabled(0)
        self.water_lineEdit_lcd_2.setEnabled(0)
        self.water_lineEdit_lcd_3.setEnabled(0)
        self.sliceThickness_lineEdit_shice28.setEnabled(0)
        self.sliceThickness_lineEdit_bc28.setEnabled(0)
        self.water_lineEdit_lcd_5.setEnabled(0)
        self.water_lineEdit_lcd_7.setEnabled(0)
       
        self.resolution_lineEdit_G_10.setEnabled(0)
        #self.lineEdit_head_CTDIw.setEnabled(0)
        self.sliceThickness_lineEdit_error28.setEnabled(0)
        self.sliceThickness_lineEdit_bc2.setEnabled(0)
        self.sliceThickness_lineEdit_shice2.setEnabled(0)
        self.sliceThickness_lineEdit_error2.setEnabled(0)
        #self.lineEdit_body_CTDIw.setEnabled(0)
        self.water_label_lcd_3.setAlignment(QtCore.Qt.AlignRight)#右对齐
        self.water_label_lcd_7.setAlignment(QtCore.Qt.AlignRight)
        self.water_label_lcd_5.setAlignment(QtCore.Qt.AlignRight)
        self.water_label_lcd_2.setAlignment(QtCore.Qt.AlignRight)
        self.resolution_label_G_10.setAlignment(QtCore.Qt.AlignRight)
        self.resolution_label_C_10.setAlignment(QtCore.Qt.AlignRight)
        self.resolution_label_G_50.setAlignment(QtCore.Qt.AlignRight)
        self.resolution_label_C_50.setAlignment(QtCore.Qt.AlignRight)
        self.resolution_lineEdit_C_50.setEnabled(0)
        self.resolution_lineEdit_G_50.setEnabled(0)
        self.resolution_label_y.setAlignment(QtCore.Qt.AlignRight)
        self.angle = 0
        #信号与槽设定
        #QtCore.QObject.connect(self.languageshift,QtCore.SIGNAL("clicked()"),self._trigger_english)#切换语言按钮
        QtCore.QObject.connect(self.water_pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_water)#点击水模体计算按钮，调用button_click_water
        QtCore.QObject.connect(self.linear_pushButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_linear)#点击CT线性值计算按钮，调用button_click_linear
        QtCore.QObject.connect(self.lineEdit_diam, QtCore.SIGNAL('textChanged(QString)'), self.onChanged22)#直径
        QtCore.QObject.connect(self.lineEdit_pitch, QtCore.SIGNAL('textChanged(QString)'), self.onChanged23)#螺距
        QtCore.QObject.connect(self.lineEdit_num, QtCore.SIGNAL('textChanged(QString)'), self.onChanged24)
        QtCore.QObject.connect(self.sliceThickness_pushButton_8, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_slice8)#点击层厚测量计算按钮，调用button_click_slice8
        QtCore.QObject.connect(self.pushButton_ctxianxing, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_ctxianxing)#点击计算CT线性值按钮，调用button_click_ctxianxing
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun1, QtCore.SIGNAL('textChanged(QString)'), self.onChanged0)#CT理论线性值1编辑框内容改变时调用onChanged0
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun2, QtCore.SIGNAL('textChanged(QString)'), self.onChanged1)#CT理论线性值2编辑框内容改变时调用onChanged1
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun3, QtCore.SIGNAL('textChanged(QString)'), self.onChanged2)#CT理论线性值3编辑框内容改变时调用onChanged2
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun4, QtCore.SIGNAL('textChanged(QString)'), self.onChanged3)#CT理论线性值4编辑框内容改变时调用onChanged3
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun5, QtCore.SIGNAL('textChanged(QString)'), self.onChanged4)#CT理论线性值5编辑框内容改变时调用onChanged4
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun6, QtCore.SIGNAL('textChanged(QString)'), self.onChanged5)#CT理论线性值6编辑框内容改变时调用onChanged5
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun7, QtCore.SIGNAL('textChanged(QString)'), self.onChanged6)#CT理论线性值7编辑框内容改变时调用onChanged6
        QtCore.QObject.connect(self.linear_lineEdit_ctlilun8, QtCore.SIGNAL('textChanged(QString)'), self.onChanged7)#CT理论线性值8编辑框内容改变时调用onChanged7
        QtCore.QObject.connect(self.resolution_lineEdit_x, QtCore.SIGNAL('textChanged(QString)'), self.onChanged8)#高对比分辨力钨珠位置x坐标编辑框内容改变时调用onChanged8
        QtCore.QObject.connect(self.resolution_lineEdit_y, QtCore.SIGNAL('textChanged(QString)'), self.onChanged9)
#        QtCore.QObject.connect(self.lineEdit_35, QtCore.SIGNAL('textChanged(QString)'), self.onChanged9)
        QtCore.QObject.connect(self.lineEdit_head_center, QtCore.SIGNAL('textChanged(QString)'), self.onChanged11)#头部模体中心编辑框内容改变时调用onChanged11
        QtCore.QObject.connect(self.lineEdit_head_0, QtCore.SIGNAL('textChanged(QString)'), self.onChanged12)#头部模体0编辑框内容改变时调用onChanged12
        QtCore.QObject.connect(self.lineEdit_head_3, QtCore.SIGNAL('textChanged(QString)'), self.onChanged13)#头部模体3编辑框内容改变时调用onChanged13
        QtCore.QObject.connect(self.lineEdit_head_6, QtCore.SIGNAL('textChanged(QString)'), self.onChanged14)#头部模体6编辑框内容改变时调用onChanged14
        QtCore.QObject.connect(self.lineEdit_head_9, QtCore.SIGNAL('textChanged(QString)'), self.onChanged15)#头部模体9编辑框内容改变时调用onChanged15
       

        QtCore.QObject.connect(self.lineEdit_body_center, QtCore.SIGNAL('textChanged(QString)'), self.onChanged17)#体部模体中心编辑框内容改变时调用onChanged17
        QtCore.QObject.connect(self.lineEdit_body_0, QtCore.SIGNAL('textChanged(QString)'), self.onChanged18)#体部模体0编辑框内容改变时调用onChanged18
        QtCore.QObject.connect(self.lineEdit_body_3, QtCore.SIGNAL('textChanged(QString)'), self.onChanged19)#体部模体3编辑框内容改变时调用onChanged19
        QtCore.QObject.connect(self.lineEdit_body_6, QtCore.SIGNAL('textChanged(QString)'), self.onChanged20)#体部模体6编辑框内容改变时调用onChanged20
        QtCore.QObject.connect(self.lineEdit_body_9, QtCore.SIGNAL('textChanged(QString)'), self.onChanged21)#体部模体9编辑框内容改变时调用onChanged21
        #QtCore.QObject.connect(self.pushButton_5, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click5)
        QtCore.QObject.connect(self.resolution_pushButton_1, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_resolution_1)#点击高对比分辨力常规算法计算按钮，调用button_click_resolution_1
        QtCore.QObject.connect(self.pushButton_report, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_saveReport)#点击生成报告按钮，调用button_click_saveReport
        QtCore.QObject.connect(self.pushButton_head, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click8)#点击头部模体计算按钮，调用button_click8
        QtCore.QObject.connect(self.pushButton_body, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click11)#点击体部模体计算按钮，调用button_click11
        QtCore.QObject.connect(self.resolution_pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_resolution_2)#点击高对比分辨力高分辨算法计算按钮，调用button_click_resolution_2
        QtCore.QObject.connect(self.pushButton_angle, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_angle)#点击机架倾角计算按钮，调用button_click_angle
       # QtCore.QObject.connect(self.pix_label.x1, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.function)
        QtCore.QObject.connect(self.sliceThickness_pushButton_28, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_slice28)#点击层厚测量计算按钮，调用button_click_slice28
        QtCore.QObject.connect(self.sliceThickness_pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), self.button_click_slice2)#点击层厚测量计算按钮，调用button_click_slice2
        QtCore.QObject.connect(self.horizontalSlider, QtCore.SIGNAL(_fromUtf8("sliderMoved(int)")), self.update_mid)#移动滑块horizontalSlider，调用update_mid
        QtCore.QObject.connect(self.horizontalSlider1, QtCore.SIGNAL(_fromUtf8("sliderMoved(int)")), self.update_length)#移动滑块horizontalSlider1，调用update_length
        QtCore.QObject.connect(self.checkbox1, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox1)#点击勾选框1，调用toggleckbox1
        QtCore.QObject.connect(self.checkbox2, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox2)#点击勾选框2，调用toggleckbox2
        QtCore.QObject.connect(self.checkbox3, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox3)#点击勾选框3，调用toggleckbox3
        QtCore.QObject.connect(self.checkbox4, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox4)#点击勾选框4，调用toggleckbox4
        QtCore.QObject.connect(self.checkbox5, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox5)#点击勾选框5，调用toggleckbox5
        QtCore.QObject.connect(self.checkbox6, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox6)#点击勾选框6，调用toggleckbox6
        QtCore.QObject.connect(self.checkbox7, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox7)#点击勾选框7，调用toggleckbox7
        QtCore.QObject.connect(self.checkbox8, QtCore.SIGNAL(_fromUtf8('clicked()')), self.toggleckbox8)#点击勾选框8，调用toggleckbox8

        self.data = np.ndarray((512, 512), np.int8)
        self.update_cw()

        if os.path.isfile(path):#加载文件
            self.load_files([path])
        elif os.path.isdir(path):
            self.load_files(dicom_files_in_dir(path))
        self.build_menu()
#勾选框被选中，相应理论值可编辑
    def toggleckbox1(self):
        if (self.checkbox1.isChecked()):
            self.linear_lineEdit_ctlilun1.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun1.setEnabled(False)

    def toggleckbox2(self):
        if (self.checkbox2.isChecked()):
            self.linear_lineEdit_ctlilun2.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun2.setEnabled(False)

    def toggleckbox3(self):
        if (self.checkbox3.isChecked()):
            self.linear_lineEdit_ctlilun3.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun3.setEnabled(False)

    def toggleckbox4(self):
        if (self.checkbox4.isChecked()):
            self.linear_lineEdit_ctlilun4.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun4.setEnabled(False)

    def toggleckbox5(self):
        if (self.checkbox5.isChecked()):
            self.linear_lineEdit_ctlilun5.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun5.setEnabled(False)

    def toggleckbox6(self):
        if (self.checkbox6.isChecked()):
            self.linear_lineEdit_ctlilun6.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun6.setEnabled(False)

    def toggleckbox7(self):
        if (self.checkbox7.isChecked()):
            self.linear_lineEdit_ctlilun7.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun7.setEnabled(False)

    def toggleckbox8(self):
        if (self.checkbox8.isChecked()):
            self.linear_lineEdit_ctlilun8.setEnabled(True)
        else:
            self.linear_lineEdit_ctlilun8.setEnabled(False)
     #调节对比度滑块，更新图像
    def update_mid(self):
        self.mid=self.horizontalSlider.value()
        self.pix_label.update_image1()

    def update_length(self):
        self.length = self.horizontalSlider1.value()
        self.pix_label.update_image1()

    #理论值输入信息存为a
    def onChanged0(self):
        self.a0=float(self.linear_lineEdit_ctlilun1.text())
        self.array3[0]=1

    def onChanged1(self):
        self.a1= float(self.linear_lineEdit_ctlilun2.text())
        self.array3[1] = 1

    def onChanged2(self):
        self.a2 =float (self.linear_lineEdit_ctlilun3.text())
        self.array3[2] = 1

    def onChanged3(self):
        self.a3 = float (self.linear_lineEdit_ctlilun4.text())
        self.array3[3] = 1

    def onChanged4(self):
        self.a4= float (self.linear_lineEdit_ctlilun5.text())
        self.array3[4] = 1

    def onChanged5(self):
        self.a5= float (self.linear_lineEdit_ctlilun6.text())
        self.array3[5] = 1

    def onChanged6(self):
        self.a6 = float (self.linear_lineEdit_ctlilun7.text())
        self.array3[6] = 1

    def onChanged7(self):
        self.a7 = float (self.linear_lineEdit_ctlilun8.text())
        self.array3[7] = 1
    #a8为钨珠x坐标，并打印a8的内容
    def onChanged8(self):
        if len(self.resolution_lineEdit_x.text())>2:
            print len(self.resolution_lineEdit_x.text())
            self.a8 = int(self.resolution_lineEdit_x.text())
            print (u'a8此刻输入的内容是：%s' % self.a8)
        else:
            self.a8=0
    
    def onChanged9(self):
        if len(self.resolution_lineEdit_y.text())>2:
            self.a9 = int(self.resolution_lineEdit_y.text())
            print (u'a9此刻输入的内容是：%s' % self.a9)
        else:
            self.a9=0
        
    #a71-75为头部模体编辑框输入的内容，打印a中内容
    def onChanged11(self):
        self.a71 = int(self.lineEdit_head_center.text())
        print (u'a71此刻输入的内容是：%s' % self.a71)
    def onChanged12(self):
        self.a72 = int(self.lineEdit_head_0.text())
        print (u'a72此刻输入的内容是：%s' % self.a72)
    def onChanged13(self):
        self.a73 = int(self.lineEdit_head_3.text())
        print (u'a73此刻输入的内容是：%s' % self.a73)
    def onChanged14(self):
        self.a74 = int(self.lineEdit_head_6.text())
        print (u'a71此刻输入的内容是：%s' % self.a74)
    def onChanged15(self):
        self.a75 = int(self.lineEdit_head_9.text())
        print (u'a71此刻输入的内容是：%s' % self.a75)
 
    #a81-85为头部模体编辑框输入的内容，打印a中内容
    def onChanged17(self):
        self.a81 = int(self.lineEdit_body_center.text())
        print (u'a81此刻输入的内容是：%s' % self.a81)

    def onChanged18(self):
        self.a82 = int(self.lineEdit_body_0.text())
        print (u'a72此刻输入的内容是：%s' % self.a82)

    def onChanged19(self):
        self.a83 = int(self.lineEdit_body_3.text())
        print (u'a73此刻输入的内容是：%s' % self.a83)

    def onChanged20(self):
        self.a84 = int(self.lineEdit_body_6.text())
        print (u'a71此刻输入的内容是：%s' % self.a84)

    def onChanged21(self):
        self.a85 = int(self.lineEdit_body_9.text())
        print (u'a71此刻输入的内容是：%s' % self.a85)

    def onChanged22(self):#直径
        self.diam = float(self.lineEdit_diam.text())
        print (u'diam此刻输入的内容是：%s' % self.diam)
        
    def onChanged23(self):#螺距
        self.pitch = int(self.lineEdit_pitch.text())
        print (u'pitch此刻输入的内容是：%s' % self.pitch)

    def onChanged24(self):#螺旋珠数量
        self.beadsnum = int(self.lineEdit_num.text())
        print (u'beadsnum此刻输入的内容是：%s' % self.beadsnum)
 
 
       
    #选择菜单中切换语言为英语，调用languageok，，文件中写1，并提示用户重启界面
    def english(self):
        lan=languageok()
        lan.langu(1)
        reply = QMessageBox.information(self,  # 使用infomation信息框
                                        u'提示',
                                        u'您确定使用英文界面吗？',
                                        QMessageBox.Yes| QMessageBox.No)
        #if (reply == 16384 ):
        #    self.close()
        #return
    #选择菜单中切换语言为汉语，调用languageok，，文件中写0，并提示用户重启界面
    def chinese(self):
        lan=languageok()
        lan.langu(0)
        reply = QMessageBox.information(self,  # 使用infomation信息框
                                        u'!',
                                        u'Quit and use Chinese？',
                                        QMessageBox.Yes| QMessageBox.No)
        #if (reply == 16384 ):
        #    self.close()
        #return
        
    def button_click_angle(self):#计算机架倾角
       fname = self.file_name
       self.lineEdit_angle.setText(str( "%.3f"%estimate_tilt_angle(fname,IsFile=True)))
       self.angle=estimate_tilt_angle(fname,IsFile=True)

    def button_click_water(self):#计算水模体指标
        fname =self.file_name
        fname = fname.replace('/', '\\\\')
        #fname = str(fname);
        ds = dicom.read_file(fname)

        test = Water_Phantom(fname)
        av, noise = test.water_roi()
        homogeneity = test.homogeneity()
        sz1 = 2 # mm
        sz = int(round(sz1 / ds.PixelSpacing[0]))
        a2 = test.calculate_lcd(sz)

        sz1 = 3  # mm
        sz = int(round(sz1 / ds.PixelSpacing[0]))
        a3 = test.calculate_lcd(sz)
        sz1 = 5  # mm
        sz = int(round(sz1 / ds.PixelSpacing[0]))
        a5 = test.calculate_lcd(sz)
        sz1 = 7  # mm
        sz = int(round(sz1 / ds.PixelSpacing[0]))
        a7 = test.calculate_lcd(sz)
        self.av=av
        self.noise=noise*100
        self.homogeneity=homogeneity
        self.lcd=a2
        self.water_lineEdit_CT.setText("%.3f"%av);
        self.water_lineEdit_noise.setText("%.3f"%(noise * 100));
        self.water_lineEdit_junyun.setText("%.3f"%homogeneity);

       

        self.av2 = a2
        self.av3 = a3
        self.av5 = a5
        self.av7 = a7
        self.water_lineEdit_lcd_2.setText("%.3f"%(a2));
        self.water_lineEdit_lcd_3.setText("%.3f"%(a3));
        self.water_lineEdit_lcd_5.setText("%.3f"%(a5));
        self.water_lineEdit_lcd_7.setText("%.3f"%(a7));

       
    

    def button_click_linear(self):#计算CT线性值指标
            fname = self.file_name;
            fname = fname.replace('/', '\\\\')
            #fname = str(fname);
            test = Linearity_Phantom(fname)
            # then call a function to get all the CT values of the 8 rods
            x = test.get_material_CT_values()  # x include the eight CT value
            # print out the CT values sorted for the lowest to the highest

            self.array1 = sorted(x)#排序

            print(self.array1[0])
            
            self.linear_lineEdit_ctceliang1.setText("%.3f" % self.array1[0]);
            self.linear_lineEdit_ctceliang2.setText("%.3f" % self.array1[1]);
            self.linear_lineEdit_ctceliang3.setText("%.3f" % self.array1[2]);
            self.linear_lineEdit_ctceliang4.setText("%.3f" % self.array1[3]);
            self.linear_lineEdit_ctceliang5.setText("%.3f" % self.array1[4]);
            self.linear_lineEdit_ctceliang6.setText("%.3f" % self.array1[5]);
            self.linear_lineEdit_ctceliang7.setText("%.3f" % self.array1[6]);
            self.linear_lineEdit_ctceliang8.setText("%.3f" % self.array1[7]);

    def button_click_slice8(self):#计算层厚指标
        fname = self.file_name;
        fname = fname.replace('/', '\\\\')
        #fname = str(fname);
        dcm= dicom.read_file(fname)

        '''
        if (not dcm.SliceThickness >= 8):
            QMessageBox.information(self,  # 使用infomation信息框
                u'注意',
                u'当前图像层厚小于8mm，请选择满足要求的图像进行计算！',
                QMessageBox.Ok)
            #self.
            return
        '''

        try:
            #phantom = Phantom(dcm.pixel_array, float(dcm.PixelSpacing[0]))
            phantom = CT_phantom(dcm)
            spiralbeads = SpiralBeads(phantom,diameter = self.diam, pitch = self.pitch,number_beads = self.beadsnum)#, int(dcm.SliceThickness))
        except ValueError:
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                u'当前图像文件无法自动测量层厚！',
                QMessageBox.Ok)
            return
        except Exception, e:
            print e
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                #u'未知错误',
                u'错误：' + str(e),
                QMessageBox.Ok)
            return
        indices, profile_segments = spiralbeads.locate_beads()
        for i in range(1):#len(profile_segments)):
            pitch = [90, 50][i]
            segment = profile_segments[i]
            thickness = spiralbeads.get_thickness(pitch, segment)
        print "The measured slice thickness is %f"%thickness
        self.slice8_shice = thickness
        self.sliceThickness_lineEdit_shice8.setText("%.3f" % (thickness))
        data_element = dcm.data_element("SliceThickness")  # or data_element = ds[0x10,0x10]
        self.slice8_biaocheng = data_element.value
        self.sliceThickness_lineEdit_bc8.setText("%.3f" % (data_element.value))
        err1=(thickness-data_element.value)/data_element.value*100
        self.slice8_err = err1
        self.sliceThickness_lineEdit_error8.setText("%.3f" % (err1))

    def button_click_slice28(self):#计算层厚指标
        fname = self.file_name;
        fname = fname.replace('/', '\\\\')
        #fname = str(fname);
        dcm= dicom.read_file(fname)

        '''
        if (dcm.SliceThickness >= 8 or dcm.SliceThickness <2):
            QMessageBox.information(self,  # 使用infomation信息框
                u'注意',
                u'当前图像层厚不在2mm到8mm之间，请选择满足要求的图像进行计算！',
                QMessageBox.Ok)
            #self.
            return
        '''

        try:
            #phantom = Phantom(dcm.pixel_array, float(dcm.PixelSpacing[0]))
            phantom = CT_phantom(dcm)
            spiralbeads = SpiralBeads(phantom,diameter = self.diam, pitch = self.pitch,number_beads = self.beadsnum)#, int(dcm.SliceThickness))
        except ValueError:
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                u'当前图像文件无法自动测量层厚！',
                QMessageBox.Ok)
            return
        except Exception, e:
            print e
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                #u'未知错误！',
                u'错误：' + str(e),
                QMessageBox.Ok)
            return
        indices, profile_segments = spiralbeads.locate_beads()
        for i in range(1):#len(profile_segments)):
            pitch = [90, 50][i]
            segment = profile_segments[i]
            thickness = spiralbeads.get_thickness(pitch, segment)
        print "The measured slice thickness is %f"%thickness
        self.slice28_shice = thickness
        self.sliceThickness_lineEdit_shice28.setText("%.3f" % (thickness))
        data_element = dcm.data_element("SliceThickness")  # or data_element = ds[0x10,0x10]
        self.slice28_biaocheng = data_element.value
        self.sliceThickness_lineEdit_bc28.setText("%.3f" % (data_element.value))
        err1=(thickness-data_element.value)/data_element.value*100
        self.slice28_err = err1
        self.sliceThickness_lineEdit_error28.setText("%.3f" % (err1))
        

    def button_click_slice2(self):#计算层厚指标
        fname = self.file_name;
        fname = fname.replace('/', '\\\\')
        #fname = str(fname);
        dcm= dicom.read_file(fname)

        '''
        if (dcm.SliceThickness >= 2 or dcm.SliceThickness < 1):
            QMessageBox.information(self,  # 使用infomation信息框
                u'注意',
                u'当前图像层厚不在1mm到2mm之间，请选择满足要求的图像进行计算！',
                QMessageBox.Ok)
            #self.
            return
        '''

        try:
            #phantom = Phantom(dcm.pixel_array, float(dcm.PixelSpacing[0]))
            phantom = CT_phantom(dcm)
            spiralbeads = SpiralBeads(phantom,diameter = self.diam, pitch = self.pitch,number_beads = self.beadsnum)#, int(dcm.SliceThickness))
        except ValueError:
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                u'当前图像文件无法自动测量层厚！',
                QMessageBox.Ok)
            return
        except Exception, e:
            print e
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                #u'未知错误！',
                u'错误：' + str(e),
                QMessageBox.Ok)
            return
        indices, profile_segments = spiralbeads.locate_beads()
        for i in range(1):#len(profile_segments)):
            pitch = [90, 50][i]
            segment = profile_segments[i]
            thickness = spiralbeads.get_thickness(pitch, segment)
        print "The measured slice thickness is %f"%thickness
        self.slice2_shice = thickness
        self.sliceThickness_lineEdit_shice2.setText("%.3f" % (thickness))
        data_element = dcm.data_element("SliceThickness")  # or data_element = ds[0x10,0x10]
        self.slice2_biaocheng = data_element.value
        self.sliceThickness_lineEdit_bc2.setText("%.3f" % (data_element.value))
        err1=(thickness-data_element.value)/data_element.value*100
        self.slice2_err = err1
        self.sliceThickness_lineEdit_error2.setText("%.3f" % (err1))
        
    # 计算CT线性值
    def button_click_ctxianxing(self):
        try:
            # 读取用户输入的八种材料理论CT值
            self.a0=float(self.linear_lineEdit_ctlilun1.text())
            self.a1= float(self.linear_lineEdit_ctlilun2.text())
            self.a2 =float (self.linear_lineEdit_ctlilun3.text())
            self.a3 = float (self.linear_lineEdit_ctlilun4.text())
            self.a4= float (self.linear_lineEdit_ctlilun5.text())
            self.a5= float (self.linear_lineEdit_ctlilun6.text())
            self.a6 = float (self.linear_lineEdit_ctlilun7.text())
            self.a7 = float (self.linear_lineEdit_ctlilun8.text())
        except ValueError:
            QMessageBox.information(self,  # 使用infomation信息框
                u'出错',
                u'输入的理论CT值有误，请重新输入！',
                QMessageBox.Ok)
            return

        ctarray = [0,0,0,0,0,0,0,0]
        #num = 0
        x = []
        y = []
        if self.checkbox1.isChecked():
            ctarray[0] = 1
            x.append(self.array1[0])
            y.append(self.a0)
        if self.checkbox2.isChecked():
            ctarray[1] = 1
            x.append(self.array1[1])
            y.append(self.a1)
        if self.checkbox3.isChecked():
            ctarray[2] = 1
            x.append(self.array1[2])
            y.append(self.a2)
        if self.checkbox4.isChecked():
            ctarray[3] = 1
            x.append(self.array1[3])
            y.append(self.a3)
        if self.checkbox5.isChecked():
            ctarray[4] = 1
            x.append(self.array1[4])
            y.append(self.a4)
        if self.checkbox6.isChecked():
            ctarray[5] = 1
            x.append(self.array1[5])
            y.append(self.a5)
        if self.checkbox7.isChecked():
            ctarray[6] = 1
            x.append(self.array1[6])
            y.append(self.a6)
        if self.checkbox8.isChecked():
            ctarray[7] = 1
            x.append(self.array1[7])
            y.append(self.a7)
        #num = sum(ctarray)

        #sum1 = 0
        #//for i in range(0,8,1):
        #    sum1 = sum1 + self.array3[i]

        #if (sum1==0 or sum1==8):
        #    x = self.array1
        #    y = [self.a0,self.a1,self.a2,self.a3,self.a4,self.a5,self.a6,self.a7]
        # linregress(x,y)线性回归函数
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
        slope = round(slope, 3)
        intercept = round(intercept, 3)
        print slope, intercept

        def f(x, a, b):
            return a + b * x

        max2=0
        for i in range(len(x)):
            if abs(f(x[i],intercept,slope)-y[i])>max2:
                max2=abs(f(x[i],intercept,slope)-y[i])
            self.linear_lineEdit_CT.setText("%.3f"%(max2))
            self.CT_err=max2
        #plt.show()

    def button_click_resolution_1(self):#常规算法
         fname = self.file_name;
         fname = fname.replace('/', '\\\\')
         #fname = str(fname);
         #dcm = dicom.read_file(fname);
         windwidth = 9

         if self.a8!=0 and self.place==1:
             try:
                 bead = TungstenBead(#dcm.pixel_array, float(dcm.PixelSpacing[0]),
                                     fname,roiwidth=32,
                                     windowwidth=windwidth,
                                     bead_position=[self.a8, self.a9] #bead_position=[254,313],
                                     )
             except Exception, e:
                 print e
                 QMessageBox.information(self,  # 使用infomation信息框
                     u'出错',
                     #u'未知错误！',
                     u'错误：' + str(e),
                     QMessageBox.Ok)
                 return
         else:
             try:
                 bead = TungstenBead(#dcm.pixel_array, float(dcm.PixelSpacing[0]),
                                     fname, roiwidth=32,
                                     windowwidth=windwidth,
                                     #bead_position=[254,313],
                                     )

             except Exception, e:
                 print e
                 QMessageBox.information(self,  # 使用infomation信息框
                     u'出错',
                     #u'未知错误！',
                     u'错误：' + str(e),
                     QMessageBox.Ok)
                 return

         #bead.resolution10 = bead.resolution10 * 10    #lp/cm
         #bead.resolution50 = bead.resolution50 * 10
         self.resolution_lineEdit_C_10.setText("%.3f" % (bead.resolution10*10))
         self.resolution_lineEdit_C_50.setText("%.3f" % (bead.resolution50*10))
         self.resolution_lineEdit_x.setText("%d"%(bead.beadpositionx))
         self.resolution_lineEdit_y.setText("%d"%(bead.beadpositiony))

         MTF_show(self, bead.resolution10*10, bead.resolution50*10, bead.freq * 10, bead.mtf)

    def button_click_resolution_2(self):#高分辨算法
         fname = self.file_name;
         fname = fname.replace('/', '\\\\')
         #fname = str(fname);
         #dcm = dicom.read_file(fname);
         windwidth = 9
         if self.a8>1 and self.place==1:
             try:
                 bead = TungstenBead(#dcm.pixel_array, float(dcm.PixelSpacing[0]),
                                     fname,roiwidth=32,
                                     windowwidth=windwidth,
                                     bead_position=[self.a8, self.a9] #bead_position=[254,313],
                                     )
             except Exception, e:
                 print e
                 QMessageBox.information(self,  # 使用infomation信息框
                     u'出错',
                     #u'未知错误！',
                     u'错误：' + str(e),
                     QMessageBox.Ok)
                 return
         else:
             try:
                 bead = TungstenBead(#dcm.pixel_array, float(dcm.PixelSpacing[0]),
                                     fname, roiwidth=32,
                                     windowwidth=windwidth,
                                     #bead_position=[254,313],
                                     )

             except Exception, e:
                 print e
                 QMessageBox.information(self,  # 使用infomation信息框
                     u'出错',
                     #u'未知错误！',
                     u'错误：' + str(e),
                     QMessageBox.Ok)
                 return

        
         #bead.resolution10 = bead.resolution10 * 10    #lp/cm
         #bead.resolution50 = bead.resolution50 * 10
         self.resolution_lineEdit_G_10.setText("%.3f" % (bead.resolution10*10))
         self.resolution_lineEdit_G_50.setText("%.3f" % (bead.resolution50*10))
         self.resolution_lineEdit_x.setText("%d"%(bead.beadpositionx))
         self.resolution_lineEdit_y.setText("%d"%(bead.beadpositiony))
         
         MTF_show(self, bead.resolution10*10, bead.resolution50*10, bead.freq * 10, bead.mtf)

    def button_click_saveReport(self):#保存报告
      #   data_xls = []
      #  xls = xlrd.open_workbook(u"CT0095.xlsx")
     #   table = xls.sheet_by_name(u"摄影机")
     #   num_row = table.nrows
     #   num_col =table.ncols
    #    for i in range(num_row):
    #        for j in range(num_col):
     #           data_xls[i][j]=table.row(i)[j].value

     #   print data_xls.encode('utf-8'
      mgy=self.mgy
      mgy1=self.mgy1
      angle=self.angle
      av2=self.av2
      av3= self.av3
      av5 = self.av5
      av7 = self.av7
      noise=self.noise
      min1=self.min1
      max1=self.max1
      mean1=self.mean1
      lcd=self.lcd
      resolution=self.resolution
      homogeneity=self.homogeneity
      av=self.av
      slice_err8= self.slice8_err
      slice_err28 = self.slice28_err
      slice2_err = self.slice2_err
      #slice2_err = float(self.sliceThickness_lineEdit_error2.text())
      #print(slice2_err)
      resolution10=self.resolution10
      resolution50=self.resolution50
      resolution10x = self.resolution10x
      resolution50x= self.resolution50x
      CT_err=self.CT_err


      styleBoldRed = xlwt.easyxf('font: color-index black, bold off;borders:left THIN,right THIN,top THIN,bottom THIN;align:  vert center, horiz center')  # 设置字体，颜色为红色，加粗
      oldWb = xlrd.open_workbook("template.xls",
                                 formatting_info=True)  # 使用xlrd.open_workbook函数打开文件，formatting_info=True表示保留该文件的格式
      newWb = copy(oldWb)  # 通过copy函数把oldWb copy到newWb，然后通过编辑newWb来实现编辑已经存在的文件。
      sheet1 = newWb.get_sheet(0)  # 读取第一个sheet

      '''
      sheet1.write_merge(5,5, 10, 11, "%.3f"%slice8_err, styleBoldRed)
      if abs(self.slice8_err)<10:
          sheet1.write_merge(5,5,12,13,u'是', styleBoldRed)
      else:
          sheet1.write_merge(5,5,12,13,u'否', styleBoldRed)
      sheet1.write_merge(6,6, 10, 11, "%.3f"%slice28_err, styleBoldRed)
      if abs(self.slice28_err) < 25:
          sheet1.write_merge(6,6, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(6,6, 12, 13, u'否', styleBoldRed)
      sheet1.write_merge(7,7, 10, 11, "%.3f"%slice2_err, styleBoldRed)
      if abs(self.slice2_err) < 40:
          sheet1.write_merge(7,7, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(7,7, 12, 13, u'否', styleBoldRed)
      sheet1.write_merge(8,8, 10, 11, "%.3f"%av, styleBoldRed)
      if abs(self.av) < 4:
          sheet1.write_merge(8,8, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(8,8, 12, 13, u'否', styleBoldRed)
      sheet1.write_merge(9,9, 10, 11, "%.3f"%noise, styleBoldRed)
      if self.noise < 0.35:
          sheet1.write_merge(9,9, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(9,9, 12, 13, u'否', styleBoldRed)
      sheet1.write_merge(10,10, 10, 11, "%.3f"%homogeneity, styleBoldRed)
      if abs(self.homogeneity) < 5:
          sheet1.write_merge(10, 10, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(10, 10, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(19,19,10,11, "%.3f"%resolution10, styleBoldRed)
      if self.resolution10 > 6:
        sheet1.write_merge(19,19, 12, 13, u'是', styleBoldRed)
      else:
        sheet1.write_merge(19,19, 12,13, u'否', styleBoldRed)
      sheet1.write_merge(20,20, 10, 11, "%.3f" % resolution50, styleBoldRed)
      if self.resolution50 > 11:
        sheet1.write_merge(20,20, 12, 13, u'是', styleBoldRed)
      else:
        sheet1.write_merge(20,20, 12,13, u'否', styleBoldRed)

      sheet1.write_merge(21,21, 10, 11, "%.3f" % resolution10x, styleBoldRed)
      if self.resolution10x > 6:
          sheet1.write_merge(21,21, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(21,21, 12, 13, u'否', styleBoldRed)
      sheet1.write_merge(22,22, 10, 11, "%.3f" % resolution50x, styleBoldRed)
      if self.resolution50x > 11:
          sheet1.write_merge(22,22 ,12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(22,22, 12, 13, u'否', styleBoldRed)

      # 低对比可探测能力
      sheet1.write_merge(11,11, 10, 11, "%.3f"%av2, styleBoldRed)
      if self.av2 < 2.5:
          sheet1.write_merge(11,11, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(11,11, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(12,12, 10, 11, "%.3f" % av3, styleBoldRed)
      if self.av3 < 2.5:
          sheet1.write_merge(12,12, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(12,12, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(13,13, 10, 11, "%.3f" % av5, styleBoldRed)
      if self.av5 < 2.5:
          sheet1.write_merge(13,13, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(13,13, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(14,14, 10, 11, "%.3f" % av7, styleBoldRed)
      if self.av7 < 2.5:
          sheet1.write_merge(14,14, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(14, 14, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(24,24, 10, 11, "%.3f" % CT_err, styleBoldRed)
      if self.CT_err <=50:
          sheet1.write_merge(24,24, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(24,24, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(15,15, 10, 11, "%.3f" % mgy, styleBoldRed)
      if self.mgy<= 50:
          sheet1.write_merge(15,15, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(15,15, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(17,17, 10, 11, "%.3f" % mgy1, styleBoldRed)
      if self.mgy1<= 30:
          sheet1.write_merge(17,17, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(17,17, 12, 13, u'否', styleBoldRed)

      sheet1.write_merge(23,23, 10, 11, "%.3f" % angle, styleBoldRed)
      if abs(self.angle) <= 2:
          sheet1.write_merge(23,23, 12, 13, u'是', styleBoldRed)
      else:
          sheet1.write_merge(23,23, 12, 13, u'否', styleBoldRed)
     '''
      sheet1.write_merge(4, 4, 2, 2, "%.3f" % self.slice8_biaocheng, styleBoldRed) #""%.3f"%slice8_err, styleBoldRed)
      sheet1.write_merge(4, 4, 3, 3, "%.3f" % self.slice8_shice, styleBoldRed)
      sheet1.write_merge(4, 4, 4, 4, "%.3f" % self.slice8_err, styleBoldRed)
      sheet1.write_merge(5, 5, 2, 2, "%.3f" % self.slice28_biaocheng, styleBoldRed) #""%.3f"%slice8_err, styleBoldRed)
      sheet1.write_merge(5, 5, 3, 3, "%.3f" % self.slice28_shice, styleBoldRed)
      sheet1.write_merge(5, 5, 4, 4, "%.3f" % self.slice28_err, styleBoldRed)

      '''
      slice2_biaocheng = 0.0
      slice2_shice = 0.0
      slice2_err = 0.0
      try:
          slice2_biaocheng = float(self.sliceThickness_lineEdit_bc2.text())
          slice2_shice = float(self.sliceThickness_lineEdit_shice2.text())
          slice2_err = float(self.sliceThickness_lineEdit_error2.text())
      except:
          QMessageBox.information(self,  # 使用infomation信息框
                                  u'出错',
                                  u'层厚偏差输入有误，请重新输入！',
                                  QMessageBox.Ok)
          return
     '''

      sheet1.write_merge(6, 6, 2, 2, "%.3f" % self.slice2_biaocheng, styleBoldRed) #""%.3f"%slice8_err, styleBoldRed)
      sheet1.write_merge(6, 6, 3, 3, "%.3f" % self.slice2_shice, styleBoldRed)
      sheet1.write_merge(6, 6, 4, 4, "%.3f" % self.slice2_err, styleBoldRed)

      sheet1.write_merge(7, 7, 3, 3, "%.3f" % angle, styleBoldRed)
      sheet1.write_merge(9, 11, 3, 3, "%.3f" % av, styleBoldRed)
      sheet1.write_merge(12, 13, 3, 3, "%.3f" % homogeneity, styleBoldRed)
      sheet1.write_merge(14, 15, 3, 3, "%.3f" % noise, styleBoldRed)
      sheet1.write_merge(16, 18, 3, 3, "%.3f" % resolution10, styleBoldRed)
      sheet1.write_merge(19, 21, 3, 3, "%.3f" % resolution10x, styleBoldRed)
      sheet1.write_merge(22, 22, 3, 4, "HU=%.3f" % av2, styleBoldRed)
      sheet1.write_merge(23, 23, 3, 4, "HU=%.3f" % av3, styleBoldRed)
      sheet1.write_merge(24, 24, 3, 4, "HU=%.3f" % av5, styleBoldRed)
      sheet1.write_merge(25, 25, 3, 4, "HU=%.3f" % av7, styleBoldRed)
      sheet1.write_merge(26, 26, 3, 3, "%.3f" % self.array1[0], styleBoldRed)
      sheet1.write_merge(27, 27, 3, 3, "%.3f" % self.array1[1], styleBoldRed)
      sheet1.write_merge(28, 28, 3, 3, "%.3f" % self.array1[2], styleBoldRed)
      sheet1.write_merge(29, 29, 3, 3, "%.3f" % self.array1[3], styleBoldRed)
      sheet1.write_merge(30, 30, 3, 3, "%.3f" % self.array1[4], styleBoldRed)
      sheet1.write_merge(31, 31, 3, 3, "%.3f" % self.array1[5], styleBoldRed)
      sheet1.write_merge(32, 32, 3, 3, "%.3f" % self.array1[6], styleBoldRed)
      sheet1.write_merge(33, 33, 3, 3, "%.3f" % self.array1[7], styleBoldRed)

      file_name = QtWidgets.QFileDialog.getSaveFileName(
          self,
          "Save file",
          os.path.expanduser(_fromUtf8(u'~/CT检测结果')),
          "xls (*.xls)"
      )
      if file_name:
          newWb.save(file_name)
      newWb.save("0.xls")  # 文件保存为"E:\\0.xls"


    def button_click8(self):    #头部模体计算指标
        s1=(self.a72 + self.a73 + self.a74 + self.a75) / 6
        s2=self.a71 / 3 +s1
        #s3=s2/(self.a76)
        self.mgy=s2
        self.lineEdit_head_CTDIw.setText("%.3f"%s2)




    def button_click11(self):   #体部模体计算
        s1 = (self.a82 + self.a83 + self.a84 + self.a85) / 6
        s2 = self.a81 / 3 + s1
        self.mgy1 = s2
        self.lineEdit_body_CTDIw.setText("%.3f" % s2)

    def open_directory(self):#打开文件
        dialog = QtWidgets.QFileDialog(self)
        dialog.setFileMode(QtWidgets.QFileDialog.DirectoryOnly)
        dialog.setViewMode(QtWidgets.QFileDialog.List)
        dialog.setOption(QtWidgets.QFileDialog.ShowDirsOnly, True)
        if dialog.exec_():
            #directory = str(dialog.selectedFiles()[0])  #中文路径会出问题
            directory = dialog.selectedFiles()[0]#本身即为unicode字符串
            print 2
            self.load_files(dicom_files_in_dir(directory))
            print 1

    def export_image(self):#保存dicom图片
        file_name = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save file",
            os.path.expanduser("~/dicom-export.png"),
            "PNG images (*.png)"
        )
        if file_name:
            self.pixmap_label._image.save(file_name)

    def about(self):
        QMessageBox.information(self,  # 使用infomation信息框
            u'关于',
            u'卡迪诺科技贸易（北京）有限公司版权所有',
            QMessageBox.Ok)

    def build_menu(self):#菜单搭建
        self.file_menu = QtWidgets.QMenu('&File', self)#文件
        self.file_menu.addAction('&Open directory', self.open_directory, QtCore.Qt.CTRL + QtCore.Qt.Key_O)
    
        self.file_menu.addAction('&Image Info', self.ImageInfo , QtCore.Qt.CTRL + QtCore.Qt.Key_S)#图片信息
        self.file_menu.addAction('&Quit', self.close, QtCore.Qt.CTRL + QtCore.Qt.Key_Q)#退出
        
        self.help_menu = QtWidgets.QMenu("&Help", self)#帮助
        self.help_menu.addAction('&About', self.about)#关于
        #self.language_menu= QtWidgets.QMenu("&language", self)
        #self.language_menu.addAction('&english',self.english)
        #self.language_menu.addAction('&chinese',self.chinese)
        self.menuBar().addMenu(self.file_menu)
        self.menuBar().addMenu(self.help_menu)
        #self.menuBar().addMenu(self.language_menu)


    def ImageInfo(self):#图片信息
        if self.file_name:
            dcm= dicom.read_file(self.file_name)
            print(str(dcm))
        data_element0 = dcm.data_element("SliceThickness")
        data_element1 = dcm.data_element("Manufacturer")
        data_element2 = dcm.data_element("KVP")
        data_element3 = dcm.data_element("XRayTubeCurrent")
        data_element4 = dcm.data_element("ExposureTime")
        data_element5 = dcm.data_element("ConvolutionKernel")
        QMessageBox.information(self,  # 使用infomation信息框
                                u'图像信息',
                                'Slice Thickness:     %f\nManufacturer:     %s\nKVP:     %s\nX-RayTubeCurrent:     %d\nExposureTime:     %s\nConvolutionKernel:     %s\nPixelSpacing:     %s\nReconstructionDiameter:     %s' %(data_element0.value,data_element1.value,data_element2.value,data_element3.value,data_element4.value,data_element5.value,dcm.PixelSpacing,dcm.ReconstructionDiameter),
                                QMessageBox.Ok)
    def show_structure(self):
        if self.file_name:
            f = dicom.read_file(self.file_name)
            print(str(f))

    def toggle_full_screen(self, toggled):#全屏
        if toggled:
            self.setWindowState(QtCore.Qt.WindowFullScreen)
        else:
            self.setWindowState(QtCore.Qt.WindowNoState)

    def on_file_item_change(self):#图片切换
        if not len(self.file_list.selectedItems()):
            self.file_name = None
        else:
            item = self.file_list.selectedItems()[0]
            # print item.text()
            #self.file_name = str(item.toolTip())
            self.file_name = item.toolTip()
            #读取当前图像的部分信息
            dcm = dicom.read_file(self.file_name)
            #self.sliceThickness = dcm.data_element("SliceThickness")
            self.dcmKVP = dcm.data_element("KVP").value
            self.dcmXRayTubeCurrent = dcm.data_element("XRayTubeCurrent").value
            self.dcmExposureTime = dcm.data_element("ExposureTime").value
            #self.lineEdit_dcmKVP.setText("%d" % (self.dcmKVP))
            #self.lineEdit_dcmXRayTubeCurrent.setText("%d" % (self.dcmXRayTubeCurrent))
            #self.lineEdit_dcmExposureTime.setText("%d" % (self.dcmExposureTime))

    def load_files(self, files):
        self.file_list.clear()
        self.files = files
        for file_name in self.files:
            item = QtWidgets.QListWidgetItem(os.path.basename(file_name))
            item.setToolTip(file_name)
            self.file_list.addItem(item)
        self.file_list.setMinimumWidth(self.file_list.sizeHintForColumn(0) + 20)
        if self.files:
            self.file_name = self.files[0]

    def get_coordinates(self, i, j):
        x = self.image_position[0] + self.pixel_spacing[0] * i
        y = self.image_position[1] + self.pixel_spacing[1] * j
        z = self.image_position[2]
        return x, y, z

    @property
    def mouse_ij(self):
        '''Mouse position as voxel index in current DICOM slice.'''
        return self.mouse_y // self.zoom_factor, self.mouse_x // self.zoom_factor

    @property
    def mouse_xyz(self):
        '''Mouse position in DICOM coordinates.'''
        if self.use_fractional_coordinates:
            # TODO: Fix for zoom out
            correction = (self.zoom_factor - 1.) / (
            2. * self.zoom_factor)  # To get center of left top pixel in a zoom grid
            return self.get_coordinates(self.mouse_x / self.zoom_factor - correction,
                                        self.mouse_y / self.zoom_factor - correction)
        else:
            return self.get_coordinates(self.mouse_x // self.zoom_factor, self.mouse_y // self.zoom_factor)

    def update_coordinates(self):
        if self.file:
            x, y, z = self.mouse_xyz
            i, j = self.mouse_ij
            self.z_label.setText("z: %.2f" % z)
            if i >= 0 and j >= 0 and i < self.data.shape[0] and j < self.data.shape[1]:
                self.resolution_lineEdit_x.setText("x: %.2f" % x)
                self.lineEdit_35.setText("y: %.2f" % y)
                self.ij_label.setText("Pos: (%d, %d)" % self.mouse_ij)
                self.hu_label.setText("HU: %d" % int(self.data[i, j]))
                return
            else:
                self.hu_label.setText("HU: ???")
        else:
            self.hu_label.setText("No image")



    def update_cw(self):
       # self.cw_label.setText("W: %d C: %d" % ( (self.pix_label.po),  (self.pix_label.y)))
        self.update_coordinates()
        pass

    @property
    def file_name(self):
        return self._file_name

    @file_name.setter
    def file_name(self, value):
        try:
            self._file_name = value
            data = DicomData.from_files([self._file_name])
            self.pix_label.data = data
            self.setWindowTitle(_translate("","CT设备成像质量检测系统 - ",None) + self._file_name)
            self.place=0

        except BaseException as exc:
            print(exc)
            self.pix_label.data = None
            self.setWindowTitle(_translate("","CT设备成像质量检测系统 - No image",None))

            # try:
            #     self.image_position = np.array([float(t) for t in self.file.ImagePositionPatient])
            # except:
            #     self.image_position = np.array([1., 1., 1.])
            # self.pixel_spacing = np.array([float(t) for t in self.file.PixelSpacing])
    #def retranslateUi(self,MainWindow):
     #   self.pushButton_report.setText(_translate("scroll_area", "生成报告", None))
    def center_selected(self, x=0, y=0):
        self.center_x = x
        self.center_y = y
        print(self.center_x, self.center_y)
        info = self.center_x, ',', self.center_y
        reply = QMessageBox.information(self,  # 使用infomation信息框
                                        u'提示',
                                        u'您确定用选取的坐标(%d,%d)作为图像中心吗？'%(self.center_x,self.center_y),
                                        QMessageBox.Yes| QMessageBox.No)
        if (reply == 16384 ):
           self.place=1
           self.resolution_lineEdit_x.setText("%d"%(self.center_x))
           self.resolution_lineEdit_y.setText("%d" % ( self.center_y))
           #self.lineEdit_35.setText(str(self.center_y))
           self.a8=self.center_x
           self.a9=self.center_y
        return
  
    def update_mid(self):
        self.mid=self.horizontalSlider.value()
        if self.mid<self.length:
            self.pix_label.update_image1()

    def update_length(self):
        self.length=self.horizontalSlider1.value()
        if self.mid<self.length:
            self.pix_label.update_image1()
