<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en" sourcelanguage="zh_CN">
<context>
    <name></name>
    <message>
        <location filename="viewer.py" line="262"/>
        <source>æºæ¶å¾è§</source>
        <translation>angle</translation>
    </message>
    <message>
        <location filename="viewer.py" line="270"/>
        <source>è®¡ç®</source>
        <translation>Calculate</translation>
    </message>
    <message>
        <location filename="viewer.py" line="808"/>
        <source>çææ¥å</source>
        <translation>Generate report</translation>
    </message>
    <message>
        <location filename="viewer.py" line="195"/>
        <source>CTè®¾å¤æåè´¨éæ£æµç³»ç»</source>
        <translation>CT equipment imaging quality inspection system</translation>
    </message>
    <message>
        <location filename="viewer.py" line="254"/>
        <source>å¯¹æ¯åº¦è°è</source>
        <translation>Contrast adjustment</translation>
    </message>
    <message>
        <location filename="viewer.py" line="1919"/>
        <source>CTè®¾å¤æåè´¨éæ£æµç³»ç» - </source>
        <translation>CT equipment imaging quality inspection system</translation>
    </message>
    <message>
        <location filename="viewer.py" line="1924"/>
        <source>CTè®¾å¤æåè´¨éæ£æµç³»ç» - No image</source>
        <translation>CT equipment imaging quality inspection system-No image</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="viewer.py" line="83"/>
        <source>Machine Code:</source>
        <translation type="obsolete">Machine Code:</translation>
    </message>
    <message>
        <location filename="viewer.py" line="86"/>
        <source>ç¡®å®</source>
        <translation type="obsolete">OK</translation>
    </message>
</context>
<context>
    <name>Viewer</name>
    <message>
        <location filename="viewer.py" line="809"/>
        <source>æ°´æ¨¡ä½ææ </source>
        <translation>Water Phantom Index</translation>
    </message>
    <message>
        <location filename="viewer.py" line="869"/>
        <source>è®¡ç®</source>
        <translation>Calculate</translation>
    </message>
    <message>
        <location filename="viewer.py" line="812"/>
        <source>CTå¼(æ°´)</source>
        <translation>CT value</translation>
    </message>
    <message>
        <location filename="viewer.py" line="813"/>
        <source>åªå£°(%)</source>
        <translation>noise(%)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="814"/>
        <source>ååæ§(HU)</source>
        <translation>Uniformity(HU)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="815"/>
        <source>ä½å¯¹æ¯å¯æ¢æµè½å</source>
        <translation>Low-contrast detectability</translation>
    </message>
    <message>
        <location filename="viewer.py" line="816"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="866"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="818"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="819"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="826"/>
        <source>CTçº¿æ§å¼</source>
        <translation>CT linear value</translation>
    </message>
    <message>
        <location filename="viewer.py" line="823"/>
        <source>å«ç§ææçæµéCTå¼</source>
        <translation>The measured CT values of eight materials</translation>
    </message>
    <message>
        <location filename="viewer.py" line="824"/>
        <source>å«ç§ææççè®ºCTå¼(ç¨æ·è¾å¥)</source>
        <translation>Theoretical CT values for eight materials (user input)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="825"/>
        <source>è®¡ç®CTçº¿æ§å¼</source>
        <translation>Calculate CT linear values</translation>
    </message>
    <message>
        <location filename="viewer.py" line="827"/>
        <source>å±ååå·®(%)</source>
        <translation>Thickness deviation(%)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="838"/>
        <source>å±åæ ç§°</source>
        <translation>Thickness nominal</translation>
    </message>
    <message>
        <location filename="viewer.py" line="839"/>
        <source>å±åå®æµå¼</source>
        <translation>Thickness measured value</translation>
    </message>
    <message>
        <location filename="viewer.py" line="840"/>
        <source>ç¸å¯¹è¯¯å·®(%)</source>
        <translation>Relative error(%)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="841"/>
        <source>é«å¯¹æ¯åè¾¨å(LP/cm)</source>
        <translation>High contrast resolution (LP/cm)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="845"/>
        <source>10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="863"/>
        <source>ä¸­å¿</source>
        <translation>Center</translation>
    </message>
    <message>
        <location filename="viewer.py" line="864"/>
        <source>CTDIw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="865"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="867"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="868"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="viewer.py" line="842"/>
        <source>é¨ç ä¸­å¿(x)</source>
        <translation>Tungsten Bead Center(x)</translation>
    </message>
    <message utf8="true">
        <location filename="viewer.py" line="268"/>
        <source>机架倾角</source>
        <translation type="obsolete">angle</translation>
    </message>
    <message utf8="true">
        <location filename="viewer.py" line="814"/>
        <source>生成报告</source>
        <translation type="obsolete">Generate report</translation>
    </message>
</context>
<context>
    <name>groupBox_5</name>
    <message>
        <location filename="viewer.py" line="747"/>
        <source>å¤´é¨æ¨¡ä½</source>
        <translation>Head Phantom</translation>
    </message>
    <message>
        <location filename="viewer.py" line="748"/>
        <source>ä½é¨æ¨¡ä½</source>
        <translation>Body Phantom</translation>
    </message>
</context>
<context>
    <name>groupBox_sliceThickness</name>
    <message>
        <location filename="viewer.py" line="640"/>
        <source>å¸¸è§ç®æ³</source>
        <translation>Conventional algorithm</translation>
    </message>
    <message>
        <location filename="viewer.py" line="641"/>
        <source>é«åè¾¨ç®æ³</source>
        <translation>High-resolution algorithm</translation>
    </message>
    <message>
        <location filename="viewer.py" line="642"/>
        <source>é¨ç ä¸­å¿(y)</source>
        <translation>Tungsten Bead Center(y)</translation>
    </message>
    <message>
        <location filename="viewer.py" line="643"/>
        <source>è®¡ç®</source>
        <translation>Calculate</translation>
    </message>
    <message>
        <location filename="viewer.py" line="645"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
